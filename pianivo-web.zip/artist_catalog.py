"""Metadata search only. Recordings must be attached separately."""
import requests
import re
from rapidfuzz.fuzz import ratio

KNOWN = {"rianna": "Rihanna", "rihanna": "Rihanna", "clodplay": "Coldplay", "coldplay": "Coldplay"}


def normalized(value):
    return re.sub(r'[^\w]', '', value).casefold()


def search_catalog(query, mode="Songs"):
    query = query.strip()
    if not query: raise ValueError('Enter a song title or artist.')
    corrected = KNOWN.get(normalized(query), query)
    entity = 'musicArtist' if mode == 'Artists' else 'song'
    def lookup(term):
        response = requests.get('https://itunes.apple.com/search', params={
            'term': term, 'entity': entity, 'media': 'music', 'limit': 35}, timeout=(8, 20))
        response.raise_for_status()
        return response.json().get('results', [])
    tracks = lookup(corrected)
    if not tracks:
        # Dynamic artist spelling suggestions when the primary catalog has no match.
        try:
            response = requests.get('https://musicbrainz.org/ws/2/artist/', params={
                'query': f'artist:{normalized(query)}~2', 'fmt': 'json', 'limit': 5},
                headers={'User-Agent': 'Cadence/1.0 (local piano application)'}, timeout=(8, 15))
            response.raise_for_status()
            candidates = response.json().get('artists', [])
            best = max(candidates, key=lambda a: ratio(normalized(query), normalized(a['name'])), default=None)
            if best and ratio(normalized(query), normalized(best['name'])) >= 70:
                corrected = best['name']
                tracks = lookup(corrected)
        except requests.RequestException:
            pass
    result, seen = [], set()
    for track in tracks:
        artist = track.get('artistName', '')
        title = artist if mode == 'Artists' else track.get('trackName', '')
        key = (artist, title)
        if not title or key in seen: continue
        seen.add(key)
        result.append({'artist': artist, 'title': title, 'url': track.get('trackViewUrl', ''), 'path': '',
                       'is_artist': mode == 'Artists'})
    return result, corrected


def find_five(artist):
    artist = artist.strip()
    if not artist:
        raise ValueError('Enter an artist or song name.')
    # Common spelling correction, not a hardcoded music catalog.
    term = 'Rihanna' if artist.casefold() in ('rianna', 'rihanna') else artist
    response = requests.get('https://itunes.apple.com/search', params={
        'term': term, 'entity': 'song', 'media': 'music', 'limit': 40}, timeout=(8, 20))
    response.raise_for_status()
    result, seen = [], set()
    for track in response.json().get('results', []):
        key = (track.get('artistName', ''), track.get('trackName', ''))
        if key in seen or not key[1]:
            continue
        seen.add(key)
        result.append({'artist': key[0], 'title': key[1], 'url': track.get('trackViewUrl', ''), 'path': ''})
        if len(result) == 5:
            break
    return result
