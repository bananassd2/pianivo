"""Original phrase-based piano composition, with reproducible musical development.

Local mode is procedural, not a neural model. Cloud plans use the same arranger.
"""
import hashlib
import json
import random
import secrets
from piano_engine import Note

COMPOSER_VERSION = '2.0'
SCALES = {False: (0, 2, 4, 5, 7, 9, 11), True: (0, 2, 3, 5, 7, 8, 10)}
PROFILES = {
    'Dreamy': {'tempo': (62, 86), 'textures': ('flowing', 'spacious', 'rolling'), 'rhythms': ((4,2,2),(2,2,3,1),(3,1,2,2),(2,1,1,4))},
    'Pop': {'tempo': (104, 136), 'textures': ('pulse', 'syncopated', 'rolling'), 'rhythms': ((1,1,2,1,1,2),(3,1,1,1,2),(2,1,1,1,1,2),(1,2,1,2,2))},
    'Cinematic': {'tempo': (70, 106), 'textures': ('rolling', 'octaves', 'spacious'), 'rhythms': ((3,1,4),(2,2,2,2),(1,1,2,4),(4,1,1,2))},
    'Classical': {'tempo': (82, 126), 'textures': ('alberti', 'flowing', 'rolling'), 'rhythms': ((1,1,1,1,2,2),(2,1,1,2,2),(1,1,2,1,1,2),(2,2,1,1,2))},
    'Jazz': {'tempo': (78, 116), 'textures': ('syncopated', 'spacious', 'pulse'), 'rhythms': ((3,1,2,1,1),(1,2,1,3,1),(2,1,2,1,2),(1,3,1,1,2))},
    'Playful': {'tempo': (108, 148), 'textures': ('pulse', 'alberti', 'syncopated'), 'rhythms': ((1,1,2,2,1,1),(2,1,1,1,1,2),(1,1,1,1,2,2),(1,2,1,1,1,2))},
}


def degree_pitch(degree, tonic, minor):
    return tonic + SCALES[minor][degree % 7] + 12 * (degree // 7)


def profile_for(prompt):
    text = prompt.lower()
    for profile, words in [('Jazz', ('jazz','lounge','blues')), ('Classical', ('classical','baroque','sonata','mozart')),
                           ('Playful', ('playful','bouncy','cheerful')), ('Cinematic', ('cinematic','dramatic','epic','dark')),
                           ('Pop', ('pop','energetic','dance','bright','fast'))]:
        if any(w in text for w in words): return profile
    return 'Dreamy'


def validate_plan(plan):
    if not isinstance(plan, dict): raise ValueError('The composition plan is invalid.')
    if not isinstance(plan.get('title'), str) or not plan['title'].strip(): raise ValueError('The composition needs a title.')
    if type(plan.get('bpm')) is not int or not 50 <= plan['bpm'] <= 160: raise ValueError('Composition tempo must be 50–160 BPM.')
    if type(plan.get('tonic')) is not int or not 60 <= plan['tonic'] <= 71: raise ValueError('The composition tonic is outside the supported range.')
    if type(plan.get('minor')) is not bool: raise ValueError('The composition must specify major or minor.')
    for field, length, low, high in [('progression',4,0,6),('verse',32,-1,14),('chorus',32,-1,14),('bridge',32,-1,14)]:
        values = plan.get(field, [])
        if not isinstance(values,list) or len(values)!=length or any(type(v) is not int or not low<=v<=high for v in values):
            raise ValueError(f'The AI returned an invalid {field} pattern. Please generate again.')
    for values in plan.get('section_progressions',{}).values():
        if not isinstance(values,list) or len(values) not in (4,8) or any(type(v) is not int or not 0<=v<=6 for v in values):
            raise ValueError('The section harmony is invalid.')
    return plan


def _theme(rng, progression, rhythms, register, shape):
    melody, previous = [], register + rng.choice((0,2,4))
    for bar in range(4):
        pattern = rng.choice(rhythms)
        step = 0
        for index, length in enumerate(pattern):
            root = progression[bar]
            target = register + shape[(bar + index) % len(shape)]
            if step in (0,4) or index == len(pattern)-1:
                candidates = [root+chord+octave for chord in (0,2,4) for octave in (0,7) if 0<=root+chord+octave<=14]
                value = min(candidates,key=lambda d: abs(d-target)*.55 + abs(d-previous)*.45 + rng.random()*2)
            else:
                value = max(0,min(14,previous+rng.choice((-2,-1,1,1,2))))
            # End the question on a chord tone; answer with a longer, settled tone.
            if bar==3 and index==len(pattern)-1: value=register+rng.choice((0,2))
            rest = (index==0 and bar in (1,3) and rng.random()<.22)
            melody.extend([-1 if rest else value]*length)
            previous=value; step+=length
    return melody


def local_plans(prompt, count=5, seed=None):
    if not 1<=count<=5: raise ValueError('Choose one to five pieces.')
    seed = secrets.randbits(52) if seed is None else seed
    digest = hashlib.sha256((str(seed)+'|'+prompt.strip().lower()).encode()).hexdigest()
    rng = random.Random(int(digest,16))
    style = profile_for(prompt); profile = PROFILES[style]
    text=prompt.lower()
    minor=any(w in text for w in ('minor','sad','dark','melanch','dramatic'))
    first=('Silver','Blue','Quiet','Velvet','Golden','Wandering','Hidden','Distant','Midnight','Falling','Morning','Amber','Glass','Wild','Soft','Electric','Crystal','Starlit','Summer','Winter','Paper','Moonlit','Little','Secret')
    last=('Tides','Lanterns','Echoes','Gardens','Letters','Clouds','Footsteps','Daydreams','Windows','Rivers','Wings','Fireflies','Horizons','Reflections','Satellites','Whispers','Sparks','Waves','Paths','Skylines','Raindrops','Sunbeams','Stories','Constellations')
    progressions = [[0,5,3,4],[0,3,1,4],[5,3,0,4],[0,2,3,4],[0,4,5,3],[3,0,1,4],[0,1,4,0],[5,1,4,0]]
    shapes=((0,2,4,3,2,1),(4,3,1,2,4,2),(0,1,3,5,4,2),(2,4,5,3,1,0),(4,2,0,1,3,2))
    plans=[]; titles=set()
    for index in range(count):
        title=f'{rng.choice(first)} {rng.choice(last)}'
        while title in titles: title=f'{rng.choice(first)} {rng.choice(last)}'
        titles.add(title)
        progression=rng.choice(progressions)[:]
        chorus=rng.choice([p for p in progressions if p!=progression])[:]
        bridge=rng.choice([p for p in progressions if p not in (progression,chorus)])[:]
        shape=rng.choice(shapes)
        piece_seed=rng.getrandbits(52)
        plan={'title':title,'mood':('Reflective' if minor else 'Warm'),'bpm':rng.randint(*profile['tempo']),
              'tonic':rng.choice((60,62,63,64,65,67,69,70)), 'minor':minor,'progression':progression,
              'verse':_theme(rng,progression,profile['rhythms'],rng.choice((0,2)),shape),
              'chorus':_theme(rng,chorus,profile['rhythms'],rng.choice((4,5,7)),shape[::-1]),
              'bridge':_theme(rng,bridge,profile['rhythms'],rng.choice((1,3,5)),rng.choice(shapes)),
              'composer_version':COMPOSER_VERSION,'style':style,'seed':seed,'arrangement_seed':piece_seed,
              'accompaniment':profile['textures'][index % len(profile['textures'])],
              'section_progressions':{'verse':progression,'chorus':chorus,'bridge':bridge}}
        plans.append(validate_plan(plan))
    return plans


def prepare_cloud_plans(plans, prompt):
    """Reject copied melodic plans within a batch and give fresh arrangements an ID."""
    fingerprints=set()
    for plan in plans:
        validate_plan(plan)
        # Comparing scale-degree motifs catches duplicates even after a key/tempo change.
        fingerprint=tuple(tuple(plan[k]) for k in ('verse','chorus','bridge'))
        if fingerprint in fingerprints:
            raise ValueError('The AI returned duplicate melodies. Please generate again for a fresh set.')
        fingerprints.add(fingerprint)
        plan.setdefault('arrangement_seed',secrets.randbits(52))
        plan.setdefault('composer_version',COMPOSER_VERSION)
        plan.setdefault('style',profile_for(prompt))
    return plans


def _sections(bars):
    lengths={32:(4,8,8,4,4,4),48:(4,12,12,8,8,4),64:(4,16,16,12,12,4)}[bars]
    result=[]; start=0
    for name,length in zip(('Intro','Verse','Chorus','Bridge','Final chorus','Outro'),lengths):
        result.append((name,start,length)); start+=length
    return result


def arrangement(plan,bars=48):
    validate_plan(plan)
    if bars not in (32,48,64): raise ValueError('Choose 32, 48, or 64 bars.')
    fallback=int(hashlib.sha256(json.dumps(plan,sort_keys=True).encode()).hexdigest()[:13],16)
    rng=random.Random(plan.get('arrangement_seed',fallback))
    style=plan.get('style','Dreamy'); profile=PROFILES.get(style,PROFILES['Dreamy'])
    base_texture=plan.get('accompaniment',rng.choice(profile['textures']))
    intro_texture=rng.choice(profile['textures'])
    melody_entry=rng.choice((0, 0, 1)) if style in ('Pop', 'Classical', 'Playful') else rng.choice((0, 1, 2))
    tonic,minor=plan['tonic'],plan['minor']; notes=[]; sections=[]
    section_layout=_sections(bars)
    def add(pitch,start,duration,velocity):
        notes.append(Note(int(pitch),float(start),float(duration),max(35,min(105,int(velocity)))))
    for section,begin,length in section_layout:
        sections.append({'name':section,'bar':begin+1})
        theme_key='chorus' if 'chorus' in section.lower() else 'bridge' if section=='Bridge' else 'verse'
        progression=plan.get('section_progressions',{}).get(theme_key,plan['progression'])
        for local in range(length):
            bar=begin+local; start=bar*4
            root=progression[local%len(progression)]
            # Four-bar question/answer cadences, with a final dominant -> tonic close.
            if local%8==7: root=0
            if bar==bars-2: root=4
            if bar==bars-1: root=0
            bass=degree_pitch(root,tonic-24,minor)
            chord=[degree_pitch(root+d,tonic-12,minor) for d in (0,2,4)]
            chord=[p-12 if p>=60 else p for p in chord]
            chord=sorted(chord)
            fifth=degree_pitch(root+4,tonic-24,minor)
            velocity=49 if section in ('Intro','Outro') else 60 if section=='Verse' else 68
            if bar==bars-1:
                for pitch,v in [(bass,50),(chord[1],46),(tonic,76),(degree_pitch(2,tonic,minor),57)]: add(pitch,start,4,v)
                continue
            texture=intro_texture if section=='Intro' else 'spacious' if section=='Outro' else 'syncopated' if section=='Bridge' else base_texture
            if section=='Final chorus' and texture=='spacious': texture='rolling'
            if texture=='spacious':
                add(bass,start,2,velocity)
                for p in chord[1:]:add(p,start+2,2,velocity-9)
            elif texture in ('pulse','syncopated'):
                add(bass,start,1.5,velocity);add(fifth,start+2,1.5,velocity-3)
                for beat in ((1.,3.) if texture=='pulse' else (.5,2.5,3.5)):
                    for p in chord:add(p,start+beat,.5 if texture=='syncopated' else 1,velocity-12)
            elif texture=='octaves':
                for beat in (0,1.5,3):
                    add(bass,start+beat,.5,velocity);add(bass+12 if bass+12<60 else fifth,start+beat,.5,velocity-12)
            elif texture=='alberti':
                pattern=(chord[0],chord[2],chord[1],chord[2])*2
                for step,p in enumerate(pattern):add(p,start+step*.5,.5,velocity-8+(5 if step%4==0 else 0))
            else:
                pattern=(bass,chord[1],fifth,chord[2],chord[1],chord[0]) if texture=='rolling' else (bass,chord[0],chord[1],chord[2])
                beats=(0,.5,1.5,2,2.5,3.5) if texture=='rolling' else (0,1,2,3)
                for step,(beat,p) in enumerate(zip(beats,pattern)):
                    finish=beats[step+1] if step+1<len(beats) else 4
                    add(p,start+beat,finish-beat,velocity-7+(6 if step==0 else 0))
            if section=='Intro' and local<melody_entry:continue
            phrase=plan[theme_key][(local%4)*8:(local%4+1)*8]
            # Keep recognizable motifs but answer/develop them on later phrases.
            developed=phrase[:]
            if local>=4 or section in ('Bridge','Final chorus','Outro'):
                for index,d in enumerate(developed):
                    if d<0:continue
                    shift=0
                    if section=='Bridge':shift=-2 if index%4 else 1
                    elif section=='Final chorus':shift=2 if index in (2,3,6,7) else 0
                    elif (local//4)%2:shift=rng.choice((-2,2)) if index in (4,5) else 0
                    developed[index]=max(0,min(14,d+shift))
                if local%4==3:developed[-2:]=[0 if local%8==7 or section=='Outro' else 4]*2
                if section=='Outro':developed[4:]=[developed[4]]*4
            step=0
            while step<8:
                d=developed[step];duration=1
                while step+duration<8 and developed[step+duration]==d:duration+=1
                if d>=0:
                    strength=86 if 'chorus' in section.lower() else 75
                    add(degree_pitch(d,tonic,minor),start+step*.5,duration*.5,strength+rng.randint(-5,5))
                step+=duration
    # Overlapping accompaniment voices must not retrigger the same held key.
    grouped={}
    for n in sorted(notes,key=lambda n:(n.start,n.pitch,-n.velocity)):
        key=(n.pitch,n.start)
        if key not in grouped:grouped[key]=n
    per_pitch={}; cleaned=[]
    for n in sorted(grouped.values(),key=lambda n:(n.start,n.pitch)):
        previous_index=per_pitch.get(n.pitch)
        if previous_index is not None:
            previous=cleaned[previous_index]
            if previous.start+previous.duration>n.start:
                cleaned[previous_index]=Note(previous.pitch,previous.start,n.start-previous.start,previous.velocity)
        per_pitch[n.pitch]=len(cleaned);cleaned.append(n)
    return sorted(cleaned,key=lambda n:(n.start,n.pitch)),sections
