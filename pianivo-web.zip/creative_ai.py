"""Local creative tools. No account, API keys or remote inference."""
from pathlib import Path
import json
import subprocess
import sys

BASE = Path(__file__).resolve().parent


class AIUnavailable(ValueError):
    pass


class CreativeAI:
    @property
    def configured(self):
        try:
            from neural_music import available
            return available()
        except ImportError:
            return False

    @property
    def image_available(self):
        from local_image import available
        return available()

    def status(self):
        return {'music': {'ready': self.configured, 'name': 'SkyTNT MIDI Transformer'},
                'image': {'ready': self.image_available, 'name': 'SD-Turbo'},
                'chat': {'ready': False, 'name': 'Guided setup · built-in help'}}

    def chat(self, history):
        """Explicitly a guided help system, not a pretend conversational model."""
        query = next((m['content'].lower() for m in reversed(history) if m['role'] == 'user'), '')
        if any(w in query for w in ('youtube', 'recording', 'file', 'existing')):
            return ('Open Existing songs, find the right video or attach a recording, then generate its score. '
                    'Original recording plays that exact audio. Piano transcription plays the detected notes; '
                    'full-band recordings may need corrections. Try Isolate the piano first.')
        if any(w in query for w in ('practice', 'speed', 'beginner', 'tune')):
            return ('Open a piece in My library. Choose Piano transcription, pick a piano sound and keep A4 at '
                    '440 Hz for standard tuning. Select your level, then Generate a speed. The blue line follows '
                    'your piano notes as they play.')
        if any(w in query for w in ('character', 'picture', 'outfit', 'image')):
            return ('In Character studio, choose a character, outfit, instrument and scene, then Generate character. '
                    'SD-Turbo runs on your Mac. Describe the most important details first; hands and instruments may need another attempt.')
        if any(w in query for w in ('security', 'private', 'document', 'folder')):
            return ('Local generation uses the models inside PianoStudio. It does not search your Documents. '
                    'Recordings are opened when you choose them. Song searches and video imports need internet access.')
        return ('In Create music, describe a mood and choose Local neural AI to generate new piano notes on your Mac. '
                'Choose 1–5 pieces and a length. To learn the controls, start the 5-minute tutorial. '
                'For a song you already know, use Existing songs with its actual recording.')

    def image(self, prompt):
        if not self.image_available:
            raise AIUnavailable('The local image model is not installed. Run Install Local AI.command in the app folder.')
        result = subprocess.run([sys.executable, str(BASE / 'local_image.py'), 'generate'],
                                input=json.dumps({'prompt': prompt}), text=True, capture_output=True,
                                timeout=600, cwd=BASE)
        if result.returncode:
            raise AIUnavailable('The local image model could not finish. ' + result.stderr[-500:])
        path = Path(json.loads(result.stdout.strip().splitlines()[-1])['image'])
        if path.parent != (BASE / 'images').resolve() or not path.name.startswith('local-'):
            raise AIUnavailable('The local image engine returned an invalid output.')
        data = path.read_bytes()
        path.unlink()
        return data


def character_prompt(fields):
    if not fields.get('Character', '').strip():
        raise ValueError('Describe your character first.')
    return ', '.join(str(value).strip() for value in fields.values() if str(value).strip())
