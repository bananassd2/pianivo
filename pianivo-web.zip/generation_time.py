"""Elapsed time and honest, progress-based estimates shared by both interfaces."""
import time


def stamp(seconds):
    seconds=max(0,int(seconds))
    return f'{seconds//60}:{seconds%60:02d}'


class ProgressClock:
    def __init__(self, now=None):
        self.started=time.monotonic() if now is None else now
        self.changed=self.started
        self.progress=0.
        self.ended=None

    def observe(self,progress,now=None):
        now=time.monotonic() if now is None else now
        progress=max(0,min(99,float(progress)))
        if progress>self.progress:
            self.changed=now
            self.progress=progress

    def finish(self,now=None):
        if self.ended is None:self.ended=time.monotonic() if now is None else now

    def snapshot(self,now=None):
        now=time.monotonic() if now is None else now
        elapsed=max(0,(self.ended if self.ended is not None else now)-self.started)
        remaining=None
        if self.ended is not None:label=f'Finished in {stamp(elapsed)}'
        elif now-self.changed>20:label=f'Elapsed {stamp(elapsed)} · Still working; updating estimate…'
        elif elapsed>=2 and self.progress>=2:
            remaining=max(1,round(elapsed*(100-self.progress)/self.progress))
            label=f'Elapsed {stamp(elapsed)} · About {stamp(remaining)} remaining'
        else:label=f'Elapsed {stamp(elapsed)} · Estimating time remaining…'
        return {'elapsed_seconds':round(elapsed),'remaining_seconds':remaining,'time_label':label}
