"""SD-Turbo image inference in its own process; weights and outputs stay in the app."""
from pathlib import Path
import json
import sys
import uuid

BASE = Path(__file__).resolve().parent
MODEL = BASE / 'models/sd-turbo'
REVISION = 'b261bac6fd2cf515557d5d0707481eafa0485ec2'
FILES = ['LICENSE.md', 'README.md', 'model_index.json', 'scheduler/scheduler_config.json',
         'text_encoder/config.json', 'text_encoder/model.fp16.safetensors',
         'tokenizer/merges.txt', 'tokenizer/special_tokens_map.json', 'tokenizer/tokenizer_config.json',
         'tokenizer/vocab.json', 'unet/config.json', 'unet/diffusion_pytorch_model.fp16.safetensors',
         'vae/config.json', 'vae/diffusion_pytorch_model.fp16.safetensors']


def available():
    return (MODEL / 'ready.json').is_file() and all((MODEL / f).is_file() for f in FILES)


def install():
    import requests
    for name in FILES:
        target = MODEL / name
        if target.is_file():
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        print(f'Downloading SD-Turbo: {name}', flush=True)
        with requests.get(f'https://huggingface.co/stabilityai/sd-turbo/resolve/{REVISION}/{name}',
                          stream=True, timeout=(20, 180)) as response:
            response.raise_for_status()
            temporary = target.with_suffix(target.suffix + '.partial')
            with temporary.open('wb') as stream:
                for chunk in response.iter_content(1024 * 1024):
                    stream.write(chunk)
            temporary.replace(target)
    (MODEL / 'ready.json').write_text(json.dumps({'model': 'stabilityai/sd-turbo', 'revision': REVISION}))
    print('Local character model ready.', flush=True)


def generate(prompt):
    if not available():
        raise ValueError('Install the local image model first.')
    import os
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    import torch
    from diffusers import AutoPipelineForText2Image
    torch.set_num_threads(4)
    device = 'mps' if torch.backends.mps.is_available() else 'cpu'
    pipe = AutoPipelineForText2Image.from_pretrained(str(MODEL), local_files_only=True,
        torch_dtype=torch.float16 if device == 'mps' else torch.float32,
        variant='fp16', use_safetensors=True)
    pipe.to(device)
    pipe.enable_attention_slicing()
    generator = torch.Generator('cpu').manual_seed(uuid.uuid4().int % (2**32))
    result = pipe(prompt=prompt, num_inference_steps=2, guidance_scale=0.0,
                  height=512, width=512, generator=generator).images[0]
    target = BASE / 'images' / ('local-' + uuid.uuid4().hex + '.png')
    target.parent.mkdir(exist_ok=True)
    result.save(target)
    return target


if __name__ == '__main__':
    if sys.argv[1] == 'install':
        install()
    elif sys.argv[1] == 'generate':
        print(json.dumps({'image': str(generate(json.load(sys.stdin)['prompt']))}))
