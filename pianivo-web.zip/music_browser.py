"""Tk dialog for online discovery. Network work never touches Tk widgets."""
import queue
import random
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from urllib.parse import urlencode, urlparse, unquote
from pathlib import Path
import webbrowser

from online_music import Recording, Cancelled, download, search, validate_url


class MusicBrowser:
    def __init__(self, app):
        self.app = app
        self.window = tk.Toplevel(app.root)
        self.window.title("Discover music · Piano Studio")
        self.window.geometry("920x620")
        self.window.minsize(740, 570)
        self.window.configure(bg="#191e2a")
        self.window.transient(app.root)
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        self.events = queue.Queue()
        self.cancel = threading.Event()
        self.closed = False
        self.busy = False
        self.rows = []
        self.offset = None
        self.last_query = ""
        self.query = tk.StringVar()
        self.url = tk.StringVar()
        self.status = tk.StringVar(value="Search a title, composer, instrument, or artist. No fixed artist list.")
        self.credit = tk.StringVar(value="Select a recording to see its source and credit.")
        body = tk.Frame(self.window, bg="#191e2a", padx=24, pady=22)
        body.pack(fill="both", expand=True)
        app.label(body, "Find your next song.", 24, bold=True).pack(anchor="w")
        app.label(body, "Search free recordings here, or find any song on Google.", 11, "#9ca6bb").pack(anchor="w", pady=(6, 18))
        top = tk.Frame(body, bg="#191e2a")
        top.pack(fill="x")
        self.entry = tk.Entry(top, textvariable=self.query, bg="#262e3d", fg="white", insertbackground="white", relief="flat", font=("Helvetica", 13))
        self.entry.pack(side="left", fill="x", expand=True, ipady=10)
        self.entry.bind("<Return>", lambda e: self.find())
        self.search_button = ttk.Button(top, text="Search recordings", command=self.find)
        self.search_button.pack(side="left", padx=6)
        ttk.Button(top, text="Google ↗", command=self.google).pack(side="left")
        controls = tk.Frame(body, bg="#191e2a")
        controls.pack(fill="x", pady=10)
        self.random_button = ttk.Button(controls, text="Surprise me ↻", command=lambda: self.find(shuffle=True))
        self.random_button.pack(side="left")
        self.more_button = ttk.Button(controls, text="More results", command=lambda: self.find(more=True), state="disabled")
        self.more_button.pack(side="left", padx=6)
        app.label(controls, "Live library: Wikimedia Commons", 10, "#9ca6bb").pack(side="right")
        listing = tk.Frame(body, bg="#191e2a")
        listing.pack(fill="both", expand=True)
        self.listbox = tk.Listbox(listing, bg="#10131b", fg="#f2f0eb", selectbackground="#b8f28b", selectforeground="#172315",
                                  font=("Helvetica", 12), relief="flat", highlightthickness=0, exportselection=False)
        self.listbox.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(listing, command=self.listbox.yview)
        scroll.pack(side="right", fill="y")
        self.listbox.configure(yscrollcommand=scroll.set)
        self.listbox.bind("<<ListboxSelect>>", self.selected)
        app.label(body, textvariable=self.credit, size=10, color="#9ca6bb", wraplength=830, anchor="w", justify="left").pack(fill="x", pady=9)
        actions = tk.Frame(body, bg="#191e2a")
        actions.pack(fill="x")
        self.use_button = ttk.Button(actions, text="Use selected recording →", style="Accent.TButton", command=self.use, state="disabled")
        self.use_button.pack(side="left")
        self.source_button = ttk.Button(actions, text="View source ↗", command=self.source, state="disabled")
        self.source_button.pack(side="left", padx=8)
        app.label(body, "Have a direct audio download link? Paste it here.", 11, "#9ca6bb").pack(anchor="w", pady=(18, 7))
        direct = tk.Frame(body, bg="#191e2a")
        direct.pack(fill="x")
        tk.Entry(direct, textvariable=self.url, bg="#262e3d", fg="white", insertbackground="white", relief="flat", font=("Helvetica", 11)).pack(side="left", fill="x", expand=True, ipady=9)
        self.url_button = ttk.Button(direct, text="Import link", command=self.import_url)
        self.url_button.pack(side="left", padx=(8, 0))
        app.label(body, textvariable=self.status, size=10, color="#b8f28b", anchor="w", wraplength=830, justify="left").pack(fill="x", pady=(14, 0))
        self.entry.focus_set()
        self.after_id = self.window.after(80, self.poll)

    def set_busy(self, busy):
        self.busy = busy
        for button in (self.search_button, self.random_button, self.url_button):
            button.configure(state="disabled" if busy else "normal")
        self.more_button.configure(state="normal" if not busy and self.offset is not None else "disabled")
        self.selected()

    def find(self, shuffle=False, more=False):
        if self.busy:
            return
        query = self.last_query if more else self.query.get().strip()
        offset = self.offset if more else 0
        self.last_query = query
        self.set_busy(True)
        self.status.set("Finding a surprise recording…" if shuffle else "Searching live recordings…")
        def work():
            try:
                rows, next_offset = search(query, offset or 0, shuffle)
                if shuffle:
                    random.shuffle(rows)
                self.events.put(("results", (rows, next_offset, more, shuffle)))
            except Exception as exc:
                self.events.put(("error", str(exc)))
        threading.Thread(target=work, daemon=True).start()

    def selected(self, event=None):
        selection = self.listbox.curselection()
        available = bool(selection) and not self.busy
        self.use_button.configure(state="normal" if available else "disabled")
        self.source_button.configure(state="normal" if available else "disabled")
        if selection:
            row = self.rows[selection[0]]
            self.credit.set(f"{row.artist[:180] or 'See source for performer'} · {row.license or 'See source for license'}")

    def google(self):
        query = self.query.get().strip()
        if not query:
            self.status.set("Type a song or artist first, then choose Google.")
            return
        webbrowser.open("https://www.google.com/search?" + urlencode({"q": query + " song audio"}))
        self.status.set("Google opened. Import the recording or paste a direct audio link to create its score.")

    def source(self):
        selected = self.listbox.curselection()
        if selected:
            url = self.rows[selected[0]].page
            if urlparse(url).scheme in ("http", "https"):
                webbrowser.open(url)

    def use(self):
        selected = self.listbox.curselection()
        if selected and not self.busy:
            self.fetch(self.rows[selected[0]])

    def import_url(self):
        if self.busy:
            return
        try:
            url = validate_url(self.url.get())
        except ValueError as exc:
            self.status.set(str(exc))
            return
        title = Path(unquote(urlparse(url).path)).name or "Online recording"
        self.fetch(Recording(title=title, url=url))

    def fetch(self, row):
        self.set_busy(True)
        self.status.set("Downloading the recording… Close this window to cancel.")
        def work():
            try:
                from piano import BASE
                path = download(row, BASE / "downloads", self.cancel,
                                lambda text: self.events.put(("progress", text)))
                self.events.put(("download", (path, row)))
            except Cancelled:
                pass
            except Exception as exc:
                self.events.put(("error", str(exc)))
        threading.Thread(target=work, daemon=True).start()

    def poll(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "results":
                    rows, self.offset, more, shuffle = payload
                    if not more:
                        self.rows = []
                        self.listbox.delete(0, "end")
                    seen = {r.url for r in self.rows}
                    for row in rows:
                        if row.url not in seen:
                            self.rows.append(row)
                            self.listbox.insert("end", "  " + row.title)
                            seen.add(row.url)
                    self.set_busy(False)
                    self.status.set(f"{len(self.rows)} recordings loaded. Select one to import." if self.rows else
                                    "No downloadable matches here. Try another query, Google, or a direct audio link.")
                    if shuffle and self.rows:
                        self.listbox.selection_set(0)
                        self.selected()
                        self.status.set("Your random pick is selected. Choose Use selected recording to import it.")
                elif kind == "progress":
                    self.status.set(payload)
                elif kind == "error":
                    self.set_busy(False)
                    self.status.set("Could not complete the request. Please try again.")
                    messagebox.showerror("Online music", payload, parent=self.window)
                elif kind == "download":
                    path, row = payload
                    self.app.input_path = path
                    self.app.file_label.set(row.title)
                    self.app.status.set("Online recording ready. Set the tempo and click Generate piano score.")
                    self.close()
                    return
        except queue.Empty:
            pass
        if not self.closed:
            self.after_id = self.window.after(80, self.poll)

    def close(self):
        self.cancel.set()
        self.closed = True
        if self.after_id:
            self.window.after_cancel(self.after_id)
        self.window.destroy()
