"""Offline original piano music from SkyTNT's pretrained MIDI Transformer.

This is neural inference, not a text model or an imitation of a named song.
The prompt chooses a tempo/key/mood; the model predicts all musical notes.
Weights are pinned and loaded locally. Generation never downloads files.
"""
from __future__ import annotations

from dataclasses import replace
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import secrets
import time

from piano_engine import Note

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "models" / "midi"
MODEL_ID = "skytnt/midi-model-tv2o-medium"
MODEL_REVISION = "0f8f265d4330f4e46527ac2313200254c5757f5f"
MODEL_FILES = {"model_base.onnx": 821713887, "model_token.onnx": 116661381}
MODEL_HASHES = {
    "model_base.onnx": "1af68e16a0509936caeb70d322ab30619d784c7af72df019f3a59276c67c1bc4",
    "model_token.onnx": "cce9376abe8f5c8d51d1b110580cc8501d38679af55ebd5a332e757e62ab9911",
}
MAX_CONTEXT = 1024


def available() -> bool:
    """A cheap installation check; checksums are verified at installation."""
    return (MODEL_DIR / "config.json").is_file() and all(
        (MODEL_DIR / name).is_file() and (MODEL_DIR / name).stat().st_size == size
        for name, size in MODEL_FILES.items()
    )


configured = available


def status() -> dict:
    return {"available": available(), "model": MODEL_ID, "revision": MODEL_REVISION,
            "engine": "Local MIDI Transformer", "license": "Apache-2.0",
            "download_mb": 938, "local_only": True,
            "prompt_controls": "Mood, tempo and key; not unrestricted text-to-music."}


def prompt_controls(prompt: str) -> dict:
    text = str(prompt).lower()
    controls = {"bpm": 96, "key": "C major", "sf": 0, "minor": 0, "mood": "balanced", "temperature": .95}
    if re.search(r"\b(sad|dark|melanchol\w*|minor|cinematic|dramatic)\b", text):
        controls.update(bpm=84, key="A minor", minor=1, mood="reflective", temperature=.9)
    if re.search(r"\b(slow|soft|dream\w*|sleep\w*|calm|gentle|romantic|peaceful|relax\w*)\b", text):
        controls.update(bpm=72, mood="gentle", temperature=.85)
    if re.search(r"\b(fast|energetic|upbeat|happy|dance|bright|playful)\b", text):
        controls.update(bpm=124, mood="bright", temperature=1.0)
    match = re.search(r"\b(\d{2,3})\s*bpm\b", text)
    if match:
        controls["bpm"] = max(40, min(180, int(match.group(1))))
    keys = {"c": (0, 0), "g": (1, 2), "d": (2, 4), "a": (3, 0), "e": (4, 1),
            "b": (5, 2), "f#": (6, 3), "c#": (7, 4), "f": (-1, -4),
            "bb": (-2, -5), "eb": (-3, -6), "ab": (-4, -7), "db": (-5, 0)}
    match = re.search(r"\b([a-g](?:#|b)?)\s+(major|minor)\b", text)
    if match and match.group(1) in keys:
        name, mode = match.groups(); sf = keys[name][0]
        if mode == "minor": sf -= 3
        if -7 <= sf <= 7:
            controls.update(key=f"{name[0].upper()}{name[1:]} {mode}", sf=sf, minor=int(mode == "minor"))
    return controls


@lru_cache(maxsize=1)
def _load_model():
    if not available():
        raise RuntimeError("The local neural piano model is not installed. Run the local music model setup from the project.")
    import onnxruntime as ort
    ort.disable_telemetry_events()
    from vendor.midi_model.midi_tokenizer import MIDITokenizer
    config = json.loads((MODEL_DIR / "config.json").read_text())
    tokenizer = MIDITokenizer(config["tokenizer"]["version"])
    tokenizer.set_optimise_midi(config["tokenizer"]["optimise_midi"])
    if tokenizer.vocab_size != config["tokenizer"]["vocab_size"]:
        raise RuntimeError("The local model and MIDI tokenizer do not match.")
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    options.log_severity_level = 3
    options.enable_mem_pattern = False
    sessions = tuple(ort.InferenceSession(str(MODEL_DIR / name), sess_options=options,
                                        providers=["CPUExecutionProvider"])
                     for name in MODEL_FILES)
    return (*sessions, tokenizer)


def _run_cached(model, inputs, cache):
    """Use the upstream model's KV cache without retaining unlimited history."""
    import numpy as np
    for spec in model.get_inputs():
        if spec.name.startswith("past_key_values"):
            name = spec.name.replace("past_key_values", "present")
            value = cache.get(name)
            if value is None:
                value = np.zeros((1, spec.shape[1], 0, spec.shape[3]), np.float32)
            elif value.shape[2] >= MAX_CONTEXT:
                value = value[:, :, -(MAX_CONTEXT - 1):].copy()
            inputs[spec.name] = value
    output_names = [spec.name for spec in model.get_outputs()]
    values = dict(zip(output_names, model.run(None, inputs)))
    cache.clear()
    cache.update({name: value for name, value in values.items() if name.startswith("present")})
    return values


def _sample(logits, ids, temperature, rng):
    import numpy as np
    ids = np.asarray(ids, dtype=np.int64)
    values = np.asarray(logits, dtype=np.float64).reshape(-1)[ids] / temperature
    if not np.isfinite(values).all():
        raise RuntimeError("The local neural model returned invalid probabilities.")
    # Restrict to the 20 most likely legal tokens, then nucleus sample.
    ranked = np.argsort(values)[::-1][:20]
    values = values[ranked]; ids = ids[ranked]
    probs = np.exp(values - values.max()); probs /= probs.sum()
    keep = np.cumsum(probs) - probs < .95
    probs = probs[keep]; probs /= probs.sum()
    return int(rng.choice(ids[keep], p=probs))


def _events(model, controls, rng, limit):
    """Piano-only adaptation of SkyTNT app_onnx.generate (Apache 2.0).

    The sampler emits notes only: no drums, program changes, CC messages,
    tempo changes, or extra instruments can appear in the output.
    """
    import numpy as np
    base, token_model, tokenizer = model
    prefix = [[tokenizer.bos_id] + [tokenizer.pad_id] * (tokenizer.max_token_seq - 1)]
    for event in (["time_signature", 0, 0, 0, 3, 1],
                  ["key_signature", 0, 0, 0, controls["sf"] + 7, controls["minor"]],
                  ["set_tempo", 0, 0, 0, controls["bpm"]],
                  ["patch_change", 0, 0, 1, 0, 0]):
        prefix.append(tokenizer.event2tokens(event))
    x = np.asarray([prefix], dtype=np.int64)
    base_cache = {}; previous_subbeat = 0; same_time_count = 0; recent_pitches = []
    tonic = (7 * controls["sf"] + (9 if controls["minor"] else 0)) % 12
    scale = {(tonic + n) % 12 for n in ((0,2,3,5,7,8,10) if controls["minor"] else (0,2,4,5,7,9,11))}
    for _ in range(limit):
        hidden = _run_cached(base, {"x": x}, base_cache)["hidden"][:, -1:]
        tokens = []; token_cache = {}; values = {}
        for position in range(tokenizer.max_token_seq):
            inputs = {"hidden": hidden if position == 0 else hidden[:, :0],
                      "x": np.asarray([tokens[-1:]], dtype=np.int64)}
            logits = _run_cached(token_model, inputs, token_cache)["y"]
            if position == 0:
                allowed = [tokenizer.event_ids["note"]]
            else:
                name = tokenizer.events["note"][position - 1]
                allowed_values = list(range(tokenizer.event_parameters[name]))
                if name == "channel": allowed_values = [0]
                elif name == "track": allowed_values = [1]
                elif name == "pitch":
                    allowed_values = [p for p in range(48,80) if p % 12 in scale and recent_pitches[-6:].count(p) < 2 and recent_pitches[-32:].count(p) < 5]
                elif name == "velocity": allowed_values = list(range(35, 116))
                elif name == "duration": allowed_values = [16, 32]
                elif name == "time1":
                    allowed_values = list(range(0, 5))
                    if same_time_count >= 1 and previous_subbeat == 0: allowed_values = list(range(1, 5))
                elif name == "time2":
                    floor = previous_subbeat if values.get("time1") == 0 else 0
                    if same_time_count >= 1 and values.get("time1") == 0: floor += 16
                    allowed_values = [i for i in (0,) if i >= floor]
                allowed = [tokenizer.parameter_ids[name][i] for i in allowed_values]
            picked = _sample(logits, allowed, controls["temperature"], rng)
            tokens.append(picked)
            if position:
                values[name] = picked - tokenizer.parameter_ids[name][0]
        if values["time1"] == 0 and values["time2"] == previous_subbeat:
            same_time_count += 1
        else:
            same_time_count = 0
        previous_subbeat = values["time2"]
        recent_pitches.append(values["pitch"])
        x = np.asarray([[tokens]], dtype=np.int64)
        yield tokenizer.tokens2event(tokens)


def _clean_notes(notes):
    """Resolve repeated same-pitch overlap while retaining predicted notes."""
    grouped = {}
    for note in notes:
        identity = (note.pitch, note.start)
        prior = grouped.get(identity)
        if prior is None or note.velocity > prior.velocity:
            grouped[identity] = note
    by_pitch = {}
    for note in grouped.values(): by_pitch.setdefault(note.pitch, []).append(note)
    cleaned = []
    for group in by_pitch.values():
        group.sort(key=lambda n: n.start)
        for index, note in enumerate(group):
            if index + 1 < len(group):
                note = replace(note, duration=min(note.duration, group[index + 1].start - note.start))
            if note.duration > 0: cleaned.append(note)
    return sorted(cleaned, key=lambda n: (n.start, n.pitch))


def generate_piece(prompt, bars, report, seed=None):
    """Return (notes, bpm, title, provenance) from local neural inference.

    Supported length is 1–64 bars of 4/4 (the UI offers 32, 48 and 64).
    The callback receives progress 0–100 and a human-readable stage.
    Model errors propagate; no procedural music is substituted silently.
    """
    import numpy as np
    if isinstance(bars, bool) or int(bars) != bars or not 1 <= bars <= 64:
        raise ValueError("Choose a piece length between 1 and 64 bars.")
    bars = int(bars)
    prompt = str(prompt).strip()[:2000]
    if not prompt: raise ValueError("Describe the piano music you want to create.")
    if re.search(r"\b(the song|song called|song named)\b", prompt, re.I):
        raise ValueError("For an existing song, use Existing songs and choose its recording. Create music makes original piano pieces; it cannot recreate a named song.")
    seed = secrets.randbits(32) if seed is None else int(seed)
    controls = prompt_controls(prompt)
    report(1, "Loading the local piano neural network…")
    started = time.monotonic(); model = _load_model()
    report(4, "Composing new piano notes locally…")
    notes = []; whole_beats = 0; target_beats = bars * 4
    # A generous event ceiling guards malformed output; never repeat a motif
    # to fill the requested length if inference fails to advance.
    for index, event in enumerate(_events(model, controls, np.random.default_rng(seed), bars * 64 + 128)):
        _, delta, subbeat, _, channel, pitch, velocity, ticks = event
        whole_beats += delta
        start = whole_beats + subbeat / 16
        if start >= target_beats: break
        notes.append(Note(pitch, start, min(ticks / 16, target_beats - start), velocity))
        if index % 8 == 0:
            report(min(97, 4 + 93 * start / target_beats),
                   f"Composing bar {min(bars, int(start // 4) + 1)} of {bars} · {len(notes)} notes")
    else:
        raise RuntimeError("The neural composer did not reach the requested length. Try another generation.")
    from playable import basic_arrangement
    notes = basic_arrangement(_clean_notes(notes), target_beats)
    if len(notes) < 4 or max(n.start + n.duration for n in notes) <= target_beats - 4:
        raise RuntimeError("The neural composer returned an incomplete piece. Try another generation.")
    title = {"gentle":"Quiet morning", "bright":"Sunlit steps", "reflective":"Evening reflections"}.get(controls["mood"],"Piano daydream")
    title += f" · {seed % 10000:04d}"
    metadata = {"engine": "neural-midi", "model": MODEL_ID, "model_revision": MODEL_REVISION,
                "composer_version": "SkyTNT tv2o-medium / Cadence 2 basic", "seed": seed,
                "bars_requested": bars, "bars_generated": bars,
                "prompt": prompt, "prompt_controls": controls,
                "prompt_limitations": "Mood, tempo and key controls; this MIDI model does not understand unrestricted text.",
                "arrangement": "Basic: one note per hand, quarter-note rhythm", "notes_predicted": len(notes), "inference_seconds": round(time.monotonic() - started, 2),
                "local_only": True, "license": "Apache-2.0"}
    report(100, f"Composed {bars} bars with the local neural piano model.")
    return notes, controls["bpm"], title, metadata


def install(report=print):
    """Explicit setup only: pinned HTTPS downloads confined to MODEL_DIR."""
    import requests
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    files = {"config.json": None, "README.md": None, **MODEL_HASHES}
    for name, expected in files.items():
        destination = MODEL_DIR / name
        if destination.is_file():
            if expected is None or hashlib.file_digest(destination.open("rb"), "sha256").hexdigest() == expected:
                continue
        remote = f"onnx/{name}" if name.endswith(".onnx") else name
        url = f"https://huggingface.co/{MODEL_ID}/resolve/{MODEL_REVISION}/{remote}"
        partial = destination.with_name(name + ".part")
        digest = hashlib.sha256()
        report(f"Installing {name} from the pinned SkyTNT release…")
        try:
            with requests.get(url, stream=True, timeout=(30, 60)) as response:
                response.raise_for_status()
                with partial.open("wb") as output:
                    for chunk in response.iter_content(1024 * 1024):
                        output.write(chunk); digest.update(chunk)
            if expected and digest.hexdigest() != expected:
                raise RuntimeError(f"Model checksum mismatch: {name}")
            partial.replace(destination)
        finally:
            partial.unlink(missing_ok=True)
    report("Local neural piano model installed and checksums verified.")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--install", action="store_true", help="Download the pinned local model (938 MB).")
    arguments = parser.parse_args()
    if arguments.install: install()
    else: print(json.dumps(status(), indent=2))
