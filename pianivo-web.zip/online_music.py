"""Live recording discovery and bounded downloads; no fixed artist catalog."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import threading
import time
from urllib.parse import unquote, urlparse
import uuid

API = "https://commons.wikimedia.org/w/api.php"
HEADERS = {"User-Agent": "PianoStudio/1.1 (personal desktop audio transcription; Wikimedia Commons discovery)"}
EXTENSIONS = {".wav", ".mp3", ".flac", ".ogg", ".oga", ".aiff", ".aif", ".mid", ".midi"}
MAX_BYTES = 100 * 1024 * 1024


class Cancelled(Exception):
    pass


class PlainText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


def plain(value):
    parser = PlainText()
    parser.feed(value)
    return " ".join(" ".join(parser.parts).split())


@dataclass
class Recording:
    title: str
    url: str
    page: str = ""
    artist: str = ""
    license: str = ""
    license_url: str = ""


def search(query: str, offset=0, random=False):
    import requests
    query = query.strip() or "piano music"
    response = requests.get(API, params={
        "action": "query", "format": "json", "generator": "search",
        "gsrsearch": f"filetype:audio {query}", "gsrnamespace": 6, "gsrlimit": 30,
        "gsroffset": offset, "gsrsort": "random" if random else "relevance",
        "prop": "imageinfo", "iiprop": "url|mime|size|extmetadata",
    }, headers=HEADERS, timeout=(8, 20))
    response.raise_for_status()
    data = response.json()
    if "error" in data:
        raise ValueError(data["error"].get("info", "The recording search is unavailable."))
    rows = []
    pages = sorted(data.get("query", {}).get("pages", {}).values(), key=lambda p: p.get("index", 0))
    for page in pages:
        info = page.get("imageinfo", [{}])[0]
        url = info.get("url", "")
        ext = Path(unquote(urlparse(url).path)).suffix.lower()
        if ext not in EXTENSIONS or info.get("size", 0) > MAX_BYTES:
            continue
        metadata = info.get("extmetadata", {})
        field = lambda name: plain(metadata.get(name, {}).get("value", ""))
        rows.append(Recording(page["title"].removeprefix("File:"), url,
                              info.get("descriptionurl", ""), field("Artist"),
                              field("LicenseShortName"), field("LicenseUrl")))
    return rows, data.get("continue", {}).get("gsroffset")


def validate_url(url):
    parsed = urlparse(url.strip())
    if parsed.scheme not in ("https", "http") or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Paste an HTTP or HTTPS link directly to an audio file, without embedded login details.")
    return url.strip()


def download(recording: Recording, folder: Path, cancel: threading.Event, progress=lambda text: None):
    import requests
    import soundfile as sf

    url = validate_url(recording.url)
    folder.mkdir(parents=True, exist_ok=True)
    temporary = folder / f"{uuid.uuid4().hex}.part"
    deadline = time.monotonic() + 120
    try:
        with requests.get(url, headers=HEADERS, stream=True, timeout=(8, 15)) as response:
            response.raise_for_status()
            validate_url(response.url)
            mime = response.headers.get("Content-Type", "").split(";")[0].lower()
            if mime in ("text/html", "application/json", "text/plain"):
                raise ValueError("That link opens a webpage. Use a direct audio download link or import an audio file.")
            length = int(response.headers.get("Content-Length", "0"))
            if length > MAX_BYTES:
                raise ValueError("This recording exceeds the 100 MB download limit.")
            size = 0
            with temporary.open("wb") as output:
                for chunk in response.iter_content(65536):
                    if cancel.is_set():
                        raise Cancelled()
                    if time.monotonic() > deadline:
                        raise ValueError("The download took too long. Please try again.")
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise ValueError("This recording exceeds the 100 MB download limit.")
                    output.write(chunk)
                    progress(f"Downloading recording · {size / 1048576:.1f} MB")
        if cancel.is_set():
            raise Cancelled()
        signature = temporary.open("rb")
        try:
            midi = signature.read(4) == b"MThd"
        finally:
            signature.close()
        if midi:
            extension = ".mid"
        else:
            try:
                info = sf.info(temporary)
            except Exception as exc:
                raise ValueError("The link did not contain supported audio. Use WAV, MP3, FLAC, OGG, AIFF, or MIDI.") from exc
            if info.duration > 600:
                raise ValueError("This recording is longer than 10 minutes. Import a shorter section.")
            if info.duration < .25:
                raise ValueError("This recording is too short to transcribe.")
            extension = {"WAV": ".wav", "FLAC": ".flac", "OGG": ".ogg", "AIFF": ".aiff", "MP3": ".mp3"}.get(info.format, ".audio")
        name = re.sub(r'[^\w .()-]', '_', Path(recording.title).stem)[:90].strip(" .") or "Online recording"
        result_dir = folder / uuid.uuid4().hex
        result_dir.mkdir()
        result = result_dir / f"{name}{extension}"
        temporary.replace(result)
        (result_dir / "source.json").write_text(json.dumps(asdict(recording), indent=2), encoding="utf-8")
        return result
    finally:
        temporary.unlink(missing_ok=True)
