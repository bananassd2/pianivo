"""Audio -> shared note timeline -> notation, MIDI, and tuned piano audio.

Heavy imports stay inside functions so the desktop UI starts immediately.
The ONNX model is supplied by Spotify's Apache-2.0 Basic Pitch package.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path
import sys


@dataclass(frozen=True)
class Note:
    pitch: int
    start: float  # quarter-note beats
    duration: float
    velocity: int = 85


def frequency(pitch: int) -> float:
    return 440.0 * 2.0 ** ((pitch - 69) / 12.0)


def report(progress: float, message: str):
    print(json.dumps({"progress": progress, "message": message}), flush=True)


def quantize(events, bpm: float, grid: float = 0.25) -> list[Note]:
    """Snap onset/end to one common grid and resolve same-pitch overlaps."""
    if not 40 <= bpm <= 240 or grid not in (0.25, 0.5, 1.0):
        raise ValueError("Use a tempo from 40 to 240 and a supported rhythm grid.")
    grouped = {}
    for start, end, pitch, amplitude, *_ in events:
        if not all(math.isfinite(float(v)) for v in (start, end, pitch, amplitude)):
            continue
        if end <= start or not 21 <= pitch <= 108:
            continue
        onset = max(0, round(start * bpm / 60 / grid)) * grid
        finish = max(onset + grid, round(end * bpm / 60 / grid) * grid)
        n = Note(int(pitch), onset, finish - onset, max(25, min(120, round(amplitude * 127))))
        key = (n.pitch, n.start)
        old = grouped.get(key)
        if old is None or n.velocity > old.velocity:
            grouped[key] = n
    by_pitch = {}
    for n in grouped.values():
        by_pitch.setdefault(n.pitch, []).append(n)
    cleaned = []
    for notes in by_pitch.values():
        notes.sort(key=lambda n: n.start)
        for i, n in enumerate(notes):
            end = n.start + n.duration
            if i + 1 < len(notes):
                end = min(end, notes[i + 1].start)
            if end > n.start:
                cleaned.append(Note(n.pitch, n.start, end - n.start, n.velocity))
    return sorted(cleaned, key=lambda n: (n.start, n.pitch))


def transcribe(path: Path, bpm: float, grid: float, threshold: float) -> list[Note]:
    import numpy as np
    import soundfile as sf
    from scipy.signal import resample_poly

    report(5, "Reading your recording…")
    try:
        with sf.SoundFile(path) as source:
            if source.frames / source.samplerate > 600:
                raise ValueError("Please use a recording under 10 minutes, or split it into sections.")
            audio = source.read(dtype="float32", always_2d=True).mean(axis=1)
            rate = source.samplerate
    except sf.LibsndfileError as exc:
        raise ValueError("Cannot decode this file. Export it as WAV, MP3, or FLAC and try again.") from exc
    if len(audio) / rate < 0.25 or not np.isfinite(audio).all():
        raise ValueError("This recording is too short or contains invalid audio.")
    if float(np.max(np.abs(audio))) < 0.0001:
        raise ValueError("This recording is silent. Choose a recording with audible notes.")
    divisor = math.gcd(rate, 22050)
    audio = resample_poly(audio, 22050 // divisor, rate // divisor).astype(np.float32)
    report(12, "Loading the local AI model…")
    from basic_pitch import build_icassp_2022_model_path, FilenameSuffix
    from basic_pitch.inference import Model, unwrap_output
    from basic_pitch.constants import AUDIO_N_SAMPLES, FFT_HOP
    from basic_pitch.note_creation import model_output_to_notes

    model = Model(build_icassp_2022_model_path(FilenameSuffix.onnx))
    overlap_frames = 30
    overlap = overlap_frames * FFT_HOP
    hop = AUDIO_N_SAMPLES - overlap
    padded = np.concatenate([np.zeros(overlap // 2, dtype=np.float32), audio])
    output = {"note": [], "onset": [], "contour": []}
    count = math.ceil(len(padded) / hop)
    for index, offset in enumerate(range(0, len(padded), hop)):
        window = padded[offset:offset + AUDIO_N_SAMPLES]
        window = np.pad(window, (0, AUDIO_N_SAMPLES - len(window)))
        prediction = model.predict(window[None, :, None])
        for key in output:
            output[key].append(prediction[key])
        report(15 + 53 * (index + 1) / count, f"Listening to the notes · section {index + 1} of {count}")
    unwrapped = {k: unwrap_output(np.concatenate(v), len(audio), overlap_frames)
                 for k, v in output.items()}
    report(70, "Separating note attacks and sustained tones…")
    _, events = model_output_to_notes(
        unwrapped, onset_thresh=threshold, frame_thresh=0.3,
        min_note_len=round(0.10 * 22050 / FFT_HOP),
        min_freq=frequency(21), max_freq=frequency(108),
        multiple_pitch_bends=False, melodia_trick=True, midi_tempo=bpm,
    )
    duration = len(audio) / 22050
    events = [(max(0, s), min(e, duration), p, a) for s, e, p, a, *_ in events if s < duration]
    notes = quantize(events, bpm, grid)
    if not notes:
        raise ValueError("No clear notes were found. Try a solo piano recording or lower the note threshold.")
    return notes


def demo_notes() -> list[Note]:
    # Public-domain melody: Twinkle, Twinkle, Little Star, opening phrase.
    pitches = [60, 60, 67, 67, 69, 69, 67, 65, 65, 64, 64, 62, 62, 60]
    durations = [1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 2]
    notes, cursor = [], 0
    for pitch, duration in zip(pitches, durations):
        notes.append(Note(pitch, cursor, duration))
        cursor += duration
    for start, chord in [(0, (48, 52)), (4, (41, 48)), (8, (53, 57)), (12, (43, 53))]:
        notes.extend(Note(p, start, 4, 60) for p in chord)
    return sorted(notes, key=lambda n: (n.start, n.pitch))


def read_midi(path: Path, bpm: float, grid: float) -> list[Note]:
    import pretty_midi
    midi = pretty_midi.PrettyMIDI(str(path))
    if midi.get_end_time() > 600:
        raise ValueError("Please choose a MIDI under 10 minutes.")
    events = [(n.start, n.end, n.pitch, n.velocity / 127)
              for part in midi.instruments if not part.is_drum for n in part.notes]
    notes = quantize(events, bpm, grid)
    if not notes:
        raise ValueError("This MIDI has no pitched notes in the piano range.")
    return notes


def create_score(notes: list[Note], bpm: float, title: str, split: int = 60, sections=None):
    from music21 import stream, note, chord, clef, meter, tempo, metadata, layout, instrument, tie
    score = stream.Score()
    score.metadata = metadata.Metadata(title=title, composer="Piano Studio · transcription draft")
    end = math.ceil(max(n.start + n.duration for n in notes) / 4) * 4
    parts = []
    for hand, selected, clef_type in [
        ("Right hand", [n for n in notes if n.pitch >= split], clef.TrebleClef),
        ("Left hand", [n for n in notes if n.pitch < split], clef.BassClef),
    ]:
        part = stream.PartStaff()
        part.partName = hand
        part.insert(0, instrument.Piano())
        part.insert(0, clef_type())
        part.insert(0, meter.TimeSignature("4/4"))
        if hand == "Right hand":
            part.insert(0, tempo.MetronomeMark(number=bpm))
            from music21 import expressions
            for section in sections or []:
                part.insert((section["bar"] - 1) * 4, expressions.TextExpression(section["name"]))
        # Slice at note and bar boundaries. Ties preserve independent held notes.
        boundaries = sorted({0, end, *range(0, end + 1, 4),
                             *(n.start for n in selected), *(n.start + n.duration for n in selected)})
        for start, finish in zip(boundaries, boundaries[1:]):
            active = [n for n in selected if n.start <= start < n.start + n.duration]
            if active:
                pitched = []
                for n in active:
                    item = note.Note(n.pitch, quarterLength=finish - start)
                    if item.pitch.accidental and item.pitch.accidental.alter == 0:
                        item.pitch.accidental = None
                    before, after = n.start < start, n.start + n.duration > finish
                    if before or after:
                        item.tie = tie.Tie("continue" if before and after else "stop" if before else "start")
                    pitched.append(item)
                item = chord.Chord(pitched) if len(pitched) > 1 else pitched[0]
                item.duration.quarterLength = finish - start
            else:
                item = note.Rest(quarterLength=finish - start)
            part.insert(start, item)
        part.makeMeasures(inPlace=True)
        part.makeTies(inPlace=True)
        parts.append(part)
        score.insert(0, part)
    score.insert(0, layout.StaffGroup(parts, name="Piano", symbol="brace", barTogether=True))
    return score


def synthesize(notes: list[Note], bpm: float, speed: float = 1.0, start_seconds: float = 0, tuning=440):
    """A440 piano-like additive synthesis; changing speed changes timing, never pitch."""
    import numpy as np
    rate = 44100
    beat = 60 / bpm / speed
    total = max(n.start + n.duration for n in notes) * beat + 0.5
    audio = np.zeros(math.ceil(total * rate), dtype=np.float32)
    for n in notes:
        held = n.duration * beat
        length = held + 0.20
        t = np.arange(math.ceil(length * rate), dtype=np.float32) / rate
        f = frequency(n.pitch) * tuning / 440
        signal = np.zeros_like(t)
        # Harmonics are exact integer multiples: no detuning or sample-rate tricks.
        for harmonic, level in [(1, 1), (2, .42), (3, .19), (4, .09), (5, .035)]:
            if harmonic * f >= rate / 2:
                continue
            signal += level * np.sin(2 * np.pi * f * harmonic * t) * np.exp(-t * (0.6 + harmonic * .38))
        envelope = np.minimum(t / .006, 1) * np.exp(-np.maximum(t - held, 0) / .045)
        signal *= envelope * (n.velocity / 127) * .22
        offset = round(n.start * beat * rate)
        count = min(len(signal), len(audio) - offset)
        audio[offset:offset + count] += signal[:count]
    peak = float(np.max(np.abs(audio)))
    if peak > .94:
        audio *= .94 / peak
    return audio[round(start_seconds * rate):], rate


def build_outputs(notes: list[Note], bpm: float, title: str, directory: Path, source: str, kind="transcription", sections=None, composition=None):
    import pretty_midi
    import soundfile as sf
    import verovio
    import resvg_py
    import xml.etree.ElementTree as ET

    directory.mkdir(parents=True, exist_ok=True)
    report(77, "Engraving both hands, rests, chords, and ties…")
    score = create_score(notes, bpm, title, sections=sections)
    if kind != "transcription":
        score.metadata.composer = "Pianivo · Original piano composition"
    source_metadata = None
    provenance = Path(source).parent / "source.json"
    if kind == "transcription" and provenance.is_file():
        source_metadata = json.loads(provenance.read_text(encoding="utf-8"))
        score.metadata.composer = source_metadata.get("artist") or "See recording source"
        (directory / "source.json").write_text(json.dumps(source_metadata, indent=2), encoding="utf-8")
    score.write("musicxml", fp=str(directory / "score.musicxml"))
    # Plain tempo text avoids font-dependent metronome glyphs in raster previews.
    xml_path = directory / "score.musicxml"
    xml = ET.parse(xml_path)
    for direction in xml.iter("direction-type"):
        for metronome in list(direction.findall("metronome")):
            direction.remove(metronome)
            ET.SubElement(direction, "words").text = f"{bpm:g} BPM"
    xml.write(xml_path, encoding="utf-8", xml_declaration=True)
    midi = pretty_midi.PrettyMIDI(initial_tempo=bpm)
    part = pretty_midi.Instrument(program=0, name="Piano")
    part.notes = [pretty_midi.Note(n.velocity, n.pitch, n.start * 60 / bpm,
                                  (n.start + n.duration) * 60 / bpm) for n in notes]
    midi.instruments.append(part)
    midi.write(str(directory / "piano.mid"))
    report(84, "Laying out printable sheet music…")
    renderer = verovio.toolkit()
    renderer.setOptions({"pageWidth": 2100, "pageHeight": 2800, "scale": 45, "svgBoundingBoxes": True,
                         "adjustPageHeight": False, "breaks": "auto", "footer": "none", "header": "none"})
    if not renderer.loadFile(str(directory / "score.musicxml")):
        raise ValueError("The score could not be engraved. Try a coarser rhythm grid.")
    pages = []
    from score_sync import page_positions, playback_map
    positions = {}
    timing = renderer.renderToTimemap()
    for number in range(1, renderer.getPageCount() + 1):
        svg = renderer.renderToSVG(number)
        positions.update(page_positions(svg, number - 1))
        # Use simple SVG text positions: nested tspan anchors differ across renderers.
        ns = "http://www.w3.org/2000/svg"
        ET.register_namespace("", ns)
        ET.register_namespace("xlink", "http://www.w3.org/1999/xlink")
        root = ET.fromstring(svg)
        label = "Transcription draft" if kind == "transcription" else "Original piano composition"
        credit = None
        if source_metadata:
            credit = f"Recording: {source_metadata.get('artist') or 'See source'} · {source_metadata.get('license') or 'See source'} · Full credit in accompanying source.json"
        from score_svg import add_print_header, normalize_svg
        add_print_header(root, title, label, number, Path(__file__).parent / 'assets' / 'pianivo-logo.png', credit)
        normalize_svg(root)
        svg = ET.tostring(root, encoding="unicode")
        (directory / f"page-{number}.svg").write_text(svg, encoding="utf-8")
        png = resvg_py.svg_to_bytes(svg_string=svg, background="white", width=1890)
        (directory / f"page-{number}.png").write_bytes(png)
        pages.append(f"page-{number}.png")
    if not pages:
        raise ValueError("No sheet-music pages were produced.")
    report(91, "Rendering tuned piano playback…")
    from piano_sound import render
    audio, rate = render(notes, bpm)
    sf.write(directory / "piano.wav", audio, rate, subtype="PCM_16")
    from PIL import Image
    pdf_pages = []
    try:
        for name in pages:
            with Image.open(directory / name) as page:
                pdf_pages.append(page.convert("RGB"))
        pdf_pages[0].save(directory / "score.pdf", "PDF", resolution=230, save_all=True, append_images=pdf_pages[1:])
    finally:
        for page in pdf_pages:
            page.close()
    result = {"title": title, "bpm": bpm, "source": source, "kind": kind, "sections": sections or [], "source_metadata": source_metadata, "pages": pages,
              "playback_map": playback_map(timing, positions, bpm),
              "notes": [asdict(n) for n in notes], "duration": max(n.start + n.duration for n in notes) * 60 / bpm,
              "composition": composition or {}}
    (directory / "session.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    report(100, "Your piano score is ready")
    print(json.dumps({"result": str(directory / "session.json")}), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--bpm", type=float, default=100)
    parser.add_argument("--grid", type=float, default=.25)
    parser.add_argument("--threshold", type=float, default=.5)
    args = parser.parse_args()
    try:
        if args.demo:
            notes, title, source = demo_notes(), "Twinkle, Twinkle, Little Star", "Built-in demonstration · public-domain melody"
        elif args.input:
            title, source = args.input.stem, str(args.input)
            if args.input.suffix.lower() in (".mid", ".midi"):
                report(10, "Reading MIDI notes…")
                notes = read_midi(args.input, args.bpm, args.grid)
            else:
                notes = transcribe(args.input, args.bpm, args.grid, args.threshold)
        else:
            raise ValueError("Choose an audio recording first.")
        build_outputs(notes, args.bpm, title, args.output, source)
    except Exception as exc:
        import traceback
        traceback.print_exc(file=sys.stderr)
        print(json.dumps({"error": str(exc)}), flush=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
