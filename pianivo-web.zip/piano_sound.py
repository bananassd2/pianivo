"""Sampled grand piano voices. Pitch and tempo are controlled independently."""
from functools import lru_cache
from pathlib import Path
import json
import math
import numpy as np

SAMPLES = Path(__file__).resolve().parent / "assets" / "grand"
VOICES = ("Baby grand · warm", "Studio grand · natural", "Concert grand · bright", "Soft felt · intimate", "Pure piano · synth")
SAMPLE_NAMES = {21: "A0", **{12 * (octave + 1) + semitone: name + str(octave)
                for octave in range(1, 8) for semitone, name in [(0, "C"), (3, "Ds"), (6, "Fs"), (9, "A")]}, 108: "C8"}


@lru_cache(maxsize=8)
def note_sample(pitch, tuning=440):
    import soundfile as sf
    from scipy.signal import resample_poly
    midi = min(SAMPLE_NAMES, key=lambda x: abs(x - pitch))
    path = SAMPLES / (SAMPLE_NAMES[midi] + ".mp3")
    if not path.is_file():
        raise ValueError("The grand piano samples are missing. Run Setup Piano Studio.command to restore them.")
    audio, sr = sf.read(path, dtype="float32", always_2d=True)
    # Ratio resampling changes pitch deliberately per note, not for practice speed.
    ratio = 2 ** ((pitch - midi) / 12) * tuning / 440
    target_rate = round(44100 / ratio)
    divisor = math.gcd(target_rate, sr)
    audio = resample_poly(audio, target_rate // divisor, sr // divisor).astype(np.float32)
    # Remove recording lead-in while preserving the hammer attack.
    level = np.max(np.abs(audio), axis=1)
    indices = np.flatnonzero(level > max(.0004, float(level.max()) * .008))
    if len(indices): audio = audio[max(0, indices[0] - 88):]
    return audio


def render(notes, bpm, speed=1.0, voice=VOICES[0], tuning=440):
    if not 40 <= bpm <= 240 or not .25 <= speed <= 2 or not 432 <= tuning <= 446:
        raise ValueError("Invalid playback tempo, speed, or tuning.")
    if voice == "Pure piano · synth":
        from piano_engine import synthesize
        audio, rate = synthesize(notes, bpm, speed, tuning=tuning)
        return np.column_stack([audio, audio]), rate
    if voice not in VOICES: raise ValueError("Unknown piano voice.")
    from scipy.signal import butter, sosfilt
    beat, rate = 60 / bpm / speed, 44100
    total = max(n.start + n.duration for n in notes) * beat + .8
    audio = np.zeros((math.ceil(total * rate), 2), dtype=np.float32)
    release = .4 if "Concert" in voice else .23 if "felt" in voice else .32
    for n in notes:
        held = n.duration * beat
        count = math.ceil((held + release) * rate)
        sample = note_sample(n.pitch, tuning)
        count = min(count, len(sample))
        sound = sample[:count].copy()
        t = np.arange(count) / rate
        envelope = np.exp(-np.maximum(t - held, 0) / (release / 5))
        sound *= (envelope * (n.velocity / 127) ** 1.35)[:, None]
        start = round(n.start * beat * rate)
        count = min(count, len(audio) - start)
        audio[start:start + count] += sound[:count]
    if "Baby" in voice or "felt" in voice:
        cutoff = 4200 if "Baby" in voice else 2100
        audio = sosfilt(butter(2, cutoff, fs=rate, output="sos"), audio, axis=0).astype(np.float32)
    if "Concert" in voice:
        # A small stereo room reflection, no chorus or pitch modulation.
        delay = int(.028 * rate)
        audio[delay:] += .10 * audio[:-delay, ::-1].copy()
    peak = float(np.max(np.abs(audio)))
    if peak > .92: audio *= .92 / peak
    return audio, rate


def install_samples():
    import requests
    from concurrent.futures import ThreadPoolExecutor
    SAMPLES.mkdir(parents=True, exist_ok=True)
    def fetch(item):
        midi, name = item
        path = SAMPLES / f"{name}.mp3"
        if path.is_file(): return
        response = requests.get(f"https://tonejs.github.io/audio/salamander/{name}.mp3", timeout=40)
        response.raise_for_status()
        temporary = path.with_suffix(".part")
        temporary.write_bytes(response.content)
        import soundfile as sf
        sf.info(temporary)
        temporary.replace(path)
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(fetch, SAMPLE_NAMES.items()))
    (SAMPLES / "LICENSE.txt").write_text("Salamander Grand Piano by Alexander Holm. CC BY 3.0.\n"
        "https://creativecommons.org/licenses/by/3.0/\nSamples distributed by https://github.com/Tonejs/audio/tree/master/salamander\n"
        "Cadence applies pitch resampling, envelopes and tone filtering. These are derived voicings of Yamaha C5 samples, not separate sampled instruments.\n")


if __name__ == "__main__":
    install_samples()
    print(f"Installed {len(SAMPLE_NAMES)} grand piano samples.")
