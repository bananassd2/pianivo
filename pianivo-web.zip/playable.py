"""Turn original model output into a basic, two-hand piano study."""
from dataclasses import replace
import math


def basic_arrangement(notes, end=None, grid=1.0):
    """One note per hand at a time on a simple, configurable rhythm grid.

    The highest detected voice becomes the right-hand melody and the lowest
    voice becomes the left-hand bass.  That keeps the recognizable outline of
    an imported song while removing unplayable note clusters.
    """
    if not notes:
        return []
    if not math.isfinite(float(grid)) or grid <= 0:
        raise ValueError("The rhythm grid must be a positive number.")
    end = end or math.ceil(max(n.start + n.duration for n in notes))
    result = []
    for low, high, right in ((60, 79, True), (48, 59, False)):
        groups = {}
        for n in notes:
            if (n.pitch >= 60) != right:
                continue
            # Use the same beat grid that was chosen for transcription.  The
            # old unconditional whole-beat rounding moved melody attacks and
            # made the piano version stop sounding like the recording.
            start = round(float(n.start) / grid) * grid
            start = round(start, 6)
            if start >= end:
                continue
            groups.setdefault(start, []).append(n)
        previous = None
        hand = []
        for start, candidates in sorted(groups.items()):
            # Prefer a clear top-line melody and a single bass foundation.
            chosen = max(candidates, key=lambda n: n.pitch) if right else min(candidates, key=lambda n: n.pitch)
            alternatives = [p for p in range(low, high + 1) if p % 12 == chosen.pitch % 12]
            pitch = min(alternatives, key=lambda p: abs(p - (previous if previous is not None else (67 if right else 53))))
            if previous is not None and abs(pitch - previous) > 7:
                # A rest gives the hand time to move rather than inventing a new pitch.
                if hand and start - hand[-1].start < 2:
                    continue
            rounded_duration = max(grid, round(float(chosen.duration) / grid) * grid)
            duration = min(2 if right else 4, rounded_duration, end-start)
            hand.append(replace(chosen, pitch=pitch, start=start, duration=duration, velocity=min(95,chosen.velocity)))
            previous = pitch
        for i, n in enumerate(hand):
            if i+1 < len(hand):
                n = replace(n, duration=min(n.duration, hand[i+1].start-n.start))
            result.append(n)
    return sorted(result, key=lambda n: (n.start, n.pitch))


def basic_transcription(notes):
    """Reduce detected chords without inventing pitches or moving note attacks.

    Keep a prominent melody and bass, shorten overlaps in the same hand, and
    leave timing rests intact. This cannot repair a wrong audio transcription.
    """
    output = []
    for right in (False, True):
        grouped = {}
        for n in notes:
            if (n.pitch >= 60) == right and 36 <= n.pitch <= 88:
                grouped.setdefault(n.start, []).append(n)
        hand = []
        for start, candidates in sorted(grouped.items()):
            previous = hand[-1] if hand else None
            def rank(n):
                continuity = min(abs(n.pitch-previous.pitch),24) if previous else 0
                register = .3 * (n.pitch-60) if right else .4*(60-n.pitch)
                return n.velocity + 5*min(n.duration,2) + register - .6*continuity
            chosen = max(candidates,key=rank)
            if previous and previous.start+previous.duration>start and chosen.velocity<previous.velocity*.65:
                continue
            if previous and abs(chosen.pitch-previous.pitch)>12 and start-previous.start<1:
                continue
            if previous:
                hand[-1] = replace(previous,duration=min(previous.duration,start-previous.start))
            hand.append(chosen)
        output.extend(hand)
    if notes and not output:
        raise ValueError('No clear notes remain in the basic piano range. Try a clearer piano recording.')
    return sorted(output,key=lambda n:(n.start,n.pitch))
