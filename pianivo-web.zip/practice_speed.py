"""Explainable practice tempo suggestions from the actual score, not a genre label."""
import math
from collections import defaultdict

LEVELS = ('Beginner', 'Intermediate', 'Advanced', 'Original')


def recommend_speed(session, level='Beginner'):
    if level not in LEVELS:
        raise ValueError('Choose Beginner, Intermediate, Advanced, or Original.')
    bpm = float(session.get('bpm', 0))
    if not math.isfinite(bpm) or not 40 <= bpm <= 240:
        raise ValueError('This score needs a valid tempo first.')
    groups = defaultdict(set)
    for note in session.get('notes', []):
        start, pitch = float(note['start']), int(note['pitch'])
        if math.isfinite(start) and start >= 0 and 21 <= pitch <= 108:
            groups[round(start, 4)].add(pitch)
    if not groups:
        raise ValueError('Generate or open a score first.')
    times = sorted(groups)
    # Peak two-beat onset density: sustained chords count as one attack, not many notes.
    left, peak = 0, 1
    for right, moment in enumerate(times):
        while moment - times[left] >= 2: left += 1
        peak = max(peak, right - left + 1)
    attacks = peak * bpm / 120
    chord_size = max(len(pitches) for pitches in groups.values())
    tops = [max(groups[t]) for t in times]
    jumps = sum(abs(b - a) >= 9 for a, b in zip(tops, tops[1:])) / max(1, len(tops) - 1)
    stretch = sum(max(v) - min(v) > 24 for v in groups.values()) / len(groups)
    if level == 'Original':
        speed = 1.0
        reason = f'Uses the score’s original {bpm:g} BPM.'
    else:
        rate, cap = {'Beginner': (2.5, 80), 'Intermediate': (4.5, 120), 'Advanced': (7.0, 200)}[level]
        difficulty = 1 + max(0, chord_size - 3) * .055 + jumps * .4 + stretch * .12
        speed = max(.25, min(1., cap / bpm, rate / max(attacks * difficulty, .1)))
        speed = round(speed * 100) / 100
        reason = (f'{level} suggestion: {round(bpm * speed)} BPM. Based on the busiest passage '
                  f'({attacks:.1f} note attacks/second), chords up to {chord_size} notes, and hand jumps. '
                  'A starting point for practice; adjust it to feel comfortable.')
    return {'level': level, 'speed': speed, 'bpm': round(bpm * speed), 'original_bpm': bpm,
            'reason': reason, 'metrics': {'peak_attacks_per_second': round(attacks, 2), 'largest_chord': chord_size}}
