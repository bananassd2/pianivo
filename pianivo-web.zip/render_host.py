"""Limited public beta: anonymous, isolated, temporary visitor studios.

One Gunicorn worker is required: in-memory job admission is shared by its threads.
No desktop sessions, recordings, model weights or credentials belong in this deploy.
"""
import atexit
import json
import os
from pathlib import Path
import secrets
import shutil
import tempfile
import threading
import time
from itsdangerous import URLSafeTimedSerializer, BadSignature
from werkzeug.wrappers import Request, Response
from web_app import create_app


class PublicStudio:
    def __init__(self, host=None):
        self.host = host or os.environ.get('RENDER_EXTERNAL_HOSTNAME', '')
        self.root = Path(tempfile.mkdtemp(prefix='pianivo-visitors-'))
        self.signer = URLSafeTimedSerializer(secrets.token_hex(32))
        self.visitors = {}
        self.lock = threading.RLock()
        self.public = create_app(self.root / 'public', hosted=True)
        self.closed = threading.Event()
        threading.Thread(target=self.sweep, daemon=True).start()
        atexit.register(self.close)

    def close(self):
        if self.closed.is_set(): return
        self.closed.set()
        with self.lock:
            for entry in self.visitors.values():
                entry['app'].extensions['cadence']['shutdown']()
            shutil.rmtree(self.root, ignore_errors=True)

    def sweep(self):
        while not self.closed.wait(10):
            with self.lock:
                now = time.monotonic()
                for key, entry in list(self.visitors.items()):
                    jobs = entry['app'].extensions['cadence']['jobs']
                    if any(j['status'] == 'running' for j in jobs.values()):
                        if now - entry['started'] > 240:
                            entry['app'].extensions['cadence']['shutdown']()
                    elif now - entry['seen'] > 3600:
                        entry['app'].extensions['cadence']['shutdown']()
                        shutil.rmtree(self.root / key, ignore_errors=True)
                        del self.visitors[key]

    @staticmethod
    def error(message, status=400):
        return Response(json.dumps({'error': message}), status=status, content_type='application/json', headers={'Cache-Control':'no-store'})

    def __call__(self, environ, start_response):
        request = Request(environ)
        # Render terminates TLS; never trust a caller-supplied forwarded host.
        if not self.host or request.host.split(':')[0] != self.host:
            return self.error('This hostname is not configured.', 403)(environ, start_response)
        origin = request.headers.get('Origin')
        if request.headers.get('Sec-Fetch-Site') == 'cross-site' or (origin and origin != 'https://' + request.host):
            return self.error('Open Pianivo directly to use the studio.', 403)(environ, start_response)
        environ = dict(environ, **{'wsgi.url_scheme': 'https'})
        if request.path == '/healthz':
            return Response('ok', content_type='text/plain')(environ, start_response)
        if request.path == '/robots.txt':
            return Response('User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /media\nDisallow: /image/\n', content_type='text/plain')(environ, start_response)
        if request.path in ('/', '/app.js', '/styles.css', '/favicon.svg', '/manifest.json', '/assets/cadence-hero.png'):
            return self.public(environ, start_response)
        if not (request.path.startswith('/api/') or request.path.startswith('/image/') or request.path == '/media'):
            return self.error('Not found.', 404)(environ, start_response)
        if request.method not in ('GET', 'POST'):
            return self.error('Method not allowed.', 405)(environ, start_response)
        if (request.content_length or 0) > 16000:
            return self.error('The request is too large.', 413)(environ, start_response)
        if request.path in ('/api/upload', '/api/image', '/api/videos', '/api/chat'):
            return self.error('This free beta supports original compositions. Audio imports and AI pictures need a larger server.', 503)(environ, start_response)
        with self.lock:
            key = None
            try:
                key = self.signer.loads(request.cookies.get('pianivo_visit', ''), max_age=3600)
            except BadSignature:
                pass
            if key not in self.visitors:
                if request.path not in ('/api/config', '/api/library'):
                    return self.error('Your temporary studio expired. Reload the page.', 401)(environ, start_response)
                if len(self.visitors) >= 24:
                    return self.error('The free studio is busy. Please try again later.', 503)(environ, start_response)
                key = secrets.token_hex(24)
                self.visitors[key] = {'app':create_app(self.root / key, hosted=True), 'seen':time.monotonic(), 'started':0, 'requests':[]}
            entry = self.visitors[key]
            now = time.monotonic()
            entry['seen'] = now
            entry['requests'] = [t for t in entry['requests'] if now-t < 60]
            if len(entry['requests']) >= 150:
                return self.error('Please slow down and try again in a minute.', 429)(environ, start_response)
            entry['requests'].append(now)
            if request.path in ('/api/generate', '/api/render', '/api/simplify'):
                if any(j['status']=='running' for v in self.visitors.values() for j in v['app'].extensions['cadence']['jobs'].values()):
                    return self.error('Another piece is being prepared. Please try again shortly.', 429)(environ, start_response)
                used = sum(p.stat().st_size for p in self.root.rglob('*') if p.is_file())
                if used > 450 * 1024**2:
                    return self.error('Temporary storage is full. Please try again later.', 507)(environ, start_response)
                data = request.get_json(silent=True) or {}
                if not isinstance(data, dict):
                    return self.error('Send a JSON object.')(environ, start_response)
                if request.path == '/api/generate' and (data.get('kind','local') != 'local' or data.get('count',1) != 1 or data.get('bars',32) != 32):
                    return self.error('The free beta offers Quick composer: one 32-bar original piece at a time. Neural AI and transcription are not enabled.')(environ, start_response)
                if request.path == '/api/render':
                    try: speed = float(data.get('speed', 1))
                    except (ValueError, TypeError): speed = 0
                    if not .75 <= speed <= 2:
                        return self.error('Choose a playback speed between 0.75× and 2× on the free server.')(environ, start_response)
                # Werkzeug cached JSON consumed the input: restore it for the inner app.
                import io
                payload = request.get_data()
                environ['wsgi.input'] = io.BytesIO(payload)
                environ['CONTENT_LENGTH'] = str(len(payload))
                entry['started'] = now
            def respond(status, headers, exc_info=None):
                cookie = Response()
                cookie.set_cookie('pianivo_visit', self.signer.dumps(key), max_age=3600, secure=True, httponly=True, samesite='Lax')
                headers += [('Set-Cookie', cookie.headers['Set-Cookie']), ('Cache-Control', 'no-store')]
                return start_response(status, headers, exc_info)
            return entry['app'](environ, respond)


application = PublicStudio()
