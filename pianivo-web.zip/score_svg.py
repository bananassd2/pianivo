"""Make Verovio pages render consistently on screen and on paper."""
import base64
from pathlib import Path
import xml.etree.ElementTree as ET
NS = '{http://www.w3.org/2000/svg}'
XLINK = '{http://www.w3.org/1999/xlink}'


def _shorten(value, limit):
    value = ' '.join(str(value).split())
    return value if len(value) <= limit else value[:limit - 1].rstrip() + '…'


def add_print_header(root, title, label, page_number, logo_path, credit=None):
    """Add a self-contained, print-safe Pianivo masthead to an SVG page.

    The logo is embedded so printed PDFs and downloaded SVGs never depend on a
    local file path or an internet connection.
    """
    width = float(root.get('width', '945px').removesuffix('px'))
    inner = root.find(NS + 'svg')
    header_height = 92
    if inner is not None:
        inner.set('y', str(header_height))
    root.set('height', f"{float(root.get('height').removesuffix('px')) + header_height:g}px")

    logo = Path(logo_path)
    if logo.is_file():
        encoded = base64.b64encode(logo.read_bytes()).decode('ascii')
        image = ET.SubElement(root, NS + 'image', {
            'x': f'{width - 73:g}', 'y': '14', 'width': '38', 'height': '38',
            'preserveAspectRatio': 'xMidYMid meet',
        })
        image.set('href', f'data:image/png;base64,{encoded}')
        image.set(XLINK + 'href', f'data:image/png;base64,{encoded}')
    ET.SubElement(root, NS + 'text', {
        'x': f'{width - 35:g}', 'y': '64', 'text-anchor': 'end',
        'font-size': '10', 'font-family': 'Arial, sans-serif',
        'font-weight': '700', 'letter-spacing': '1.4', 'fill': '#111111',
    }).text = 'PIANIVO'
    ET.SubElement(root, NS + 'text', {
        'x': '35', 'y': '31', 'font-size': '23',
        'font-family': 'Georgia, Times, serif', 'fill': '#111111',
    }).text = _shorten(title, 52)
    ET.SubElement(root, NS + 'text', {
        'x': '35', 'y': '54', 'font-size': '12',
        'font-family': 'Arial, sans-serif', 'fill': '#3f4652',
    }).text = f'Pianivo · {label} · Page {page_number}'
    if credit:
        ET.SubElement(root, NS + 'text', {
            'x': '35', 'y': '70', 'font-size': '9',
            'font-family': 'Arial, sans-serif', 'fill': '#555b65',
        }).text = _shorten(credit, 145)
    ET.SubElement(root, NS + 'line', {
        'x1': '35', 'x2': f'{width - 35:g}', 'y1': '80', 'y2': '80',
        'stroke': '#c9ccd2', 'stroke-width': '0.8',
    })
    return root


def normalize_svg(root):
    inner = root.find(NS + 'svg')
    if inner is not None:
        # A taller root must not resize/recenter the nested staff viewport.
        width = float(root.get('width').removesuffix('px'))
        box = [float(v) for v in inner.get('viewBox').split()]
        inner.set('width', f'{width:g}')
        inner.set('height', f'{width * box[3] / box[2]:g}')
    # Debug bounding-box groups inside text spans are not valid SVG text content.
    for parent in list(root.iter()):
        for child in list(parent):
            if 'bounding-box' in child.get('class', ''):
                parent.remove(child)
    for text in root.iter(NS + 'text'):
        if not len(text): continue
        words = ' '.join(''.join(text.itertext()).split())
        spans = [e for e in text.iter(NS + 'tspan') if e.get('font-size', '0px') not in ('0', '0px')]
        if spans:
            text.set('font-size', spans[0].get('font-size'))
            for attr in ('font-family', 'font-weight', 'font-style'):
                if spans[0].get(attr): text.set(attr, spans[0].get(attr))
        for child in list(text): text.remove(child)
        text.text = words
    return root
