"""Tie score geometry to musical time using Verovio's own note IDs."""
import bisect
import re
import xml.etree.ElementTree as ET

NS = "{http://www.w3.org/2000/svg}"


def page_positions(svg, page):
    root = ET.fromstring(svg)
    width = float(root.get("width").removesuffix("px"))
    inner = root.find(NS + "svg")
    view = [float(v) for v in inner.get("viewBox").split()]
    scale = width / view[2]
    margin = next((g for g in inner.iter(NS + "g") if g.get("class") == "page-margin"), None)
    dx, dy = [float(x) for x in re.findall(r'-?\d+(?:\.\d+)?', margin.get("transform"))[:2]]
    positions = {}
    for system in inner.iter(NS + "g"):
        if system.get("class") != "system": continue
        boxes = []
        for g in system.iter(NS + "g"):
            if g.get("class") in ("staff bounding-box", "note bounding-box"):
                rect = g.find(NS + "rect")
                if rect is not None: boxes.append(rect)
        if not boxes: continue
        y1 = min(float(r.get("y")) for r in boxes)
        y2 = max(float(r.get("y")) + float(r.get("height")) for r in boxes)
        for note in system.iter(NS + "g"):
            if note.get("class") != "note": continue
            box = next((g for g in note if g.get("class") == "note bounding-box"), None)
            rect = box.find(NS + "rect") if box is not None else None
            if rect is None: continue
            x = float(rect.get("x")) + float(rect.get("width")) / 2
            positions[note.get("id")] = {"page": page, "system": system.get("id"), "width": width,
                "x": (x + dx) * scale, "y1": 75 + (y1 + dy - 100) * scale,
                "y2": 75 + (y2 + dy + 100) * scale}
    return positions


def playback_map(timemap, positions, bpm):
    result = []
    for event in timemap:
        notes = [positions[n] for n in event.get("on", []) if n in positions]
        if notes:
            row = dict(min(notes, key=lambda p: p["x"]))
            row["time"] = event["qstamp"] * 60 / bpm
            result.append(row)
    return result


def cursor_at(timeline, seconds):
    if not timeline: return None
    index = bisect.bisect_right([r["time"] for r in timeline], seconds) - 1
    if index < 0: return None
    current = dict(timeline[index])
    if index + 1 < len(timeline):
        nxt = timeline[index + 1]
        if current["page"] == nxt["page"] and current["system"] == nxt["system"] and nxt["time"] > current["time"]:
            ratio = min(1, max(0, (seconds - current["time"]) / (nxt["time"] - current["time"])))
            current["x"] += (nxt["x"] - current["x"]) * ratio
    return current
