"""Save a basic copy of an existing score, retaining its real recording."""
import json
from pathlib import Path
from piano_engine import Note,build_outputs
from playable import basic_transcription,basic_arrangement
from source_audio import recording_path,archive_recordings,save_recording_metadata

def simplify(source_file, output):
    source_file,output=Path(source_file),Path(output)
    score=json.loads(source_file.read_text())
    original=[Note(**n) for n in score['notes']]
    notes=basic_transcription(original) if score['kind']=='transcription' else basic_arrangement(original)
    title=score['title'].removesuffix(' · Basic version')+' · Basic version'
    meta=dict(score.get('composition',{}));meta['arrangement']='Basic: one note per hand';meta['simplified_from']=source_file.parent.name
    build_outputs(notes,score['bpm'],title,output,score.get('source',''),score['kind'],score.get('sections',[]),composition=meta)
    real=recording_path(score,source_file.parent)
    if real:
        archive_recordings(output,real,recording_path(score,source_file.parent,'isolated'),source_title=score.get('recording_title') or score['title'])
        if score.get('source_metadata'):
            save_recording_metadata(output,{'source_metadata':score['source_metadata']})
    (output/'detected-notes.json').write_text(json.dumps(score['notes']))

if __name__=='__main__':
    import sys
    simplify(sys.argv[1],sys.argv[2])
