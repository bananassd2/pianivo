"""Keep a transcription's real recording separate from its rendered piano score.

Recordings are decoded without resampling, retuning, normalization, or trimming.
The score remains an estimate; these files let listeners compare it to the source.
"""
from __future__ import annotations

import json
from pathlib import Path
import uuid


RECORDING_FILES = {"source": "source.wav", "isolated": "isolated.wav"}
MAX_DURATION = 600
AUDIO_SUFFIXES = {".wav", ".mp3", ".flac", ".ogg", ".aif", ".aiff", ".aifc", ".m4a", ".aac"}


def _audio_info(path):
    import soundfile as sf

    path = Path(path)
    if not path.is_file() or path.suffix.lower() not in AUDIO_SUFFIXES:
        raise ValueError("The original audio recording is no longer available.")
    info = sf.info(path)
    if not 0 < info.duration <= MAX_DURATION or not 1 <= info.channels <= 8 or not 8000 <= info.samplerate <= 192000:
        raise ValueError("Choose an audio recording under 10 minutes with a supported sample rate and channel count.")
    return info


def _source_metadata(source):
    path = Path(source).parent / "source.json"
    if not path.is_file() or path.stat().st_size > 1_048_576:
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {key: str(data[key])[:2000] for key in ("title", "artist", "url", "page", "license", "license_url") if data.get(key)}


def _archive_audio(source, target):
    """Stream to a lossless float WAV, preserving decoded samples and timing."""
    import soundfile as sf

    info = _audio_info(source)
    temporary = target.with_name(f".{target.stem}-{uuid.uuid4().hex}.wav")
    try:
        with sf.SoundFile(source) as incoming, sf.SoundFile(
            temporary, mode="w", samplerate=info.samplerate, channels=info.channels,
            format="WAV", subtype="FLOAT",
        ) as outgoing:
            for block in incoming.blocks(blocksize=65536, dtype="float32", always_2d=True):
                outgoing.write(block)
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)
    return {"file": target.name, "duration": info.frames / info.samplerate,
            "sample_rate": info.samplerate, "channels": info.channels}


def save_recording_metadata(directory, metadata):
    """Attach verified recording details after the score renderer has finished."""
    directory = Path(directory)
    path = directory / "session.json"
    session = json.loads(path.read_text(encoding="utf-8"))
    session.update(metadata)
    temporary = directory / f".session-{uuid.uuid4().hex}.json"
    try:
        temporary.write_text(json.dumps(session, indent=2), encoding="utf-8")
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def archive_recordings(directory, source, isolated=None, requested_title="", source_title=None):
    """Archive real audio and return metadata; MIDI never becomes a recording.

    If a session already exists, update it too. Jobs can call this before rendering
    then pass the returned metadata to ``save_recording_metadata`` afterwards.
    """
    source, directory = Path(source), Path(directory)
    if source.suffix.lower() in {".mid", ".midi"}:
        return {}
    directory.mkdir(parents=True, exist_ok=True)
    provenance = _source_metadata(source)
    title = str(source_title or provenance.get("title") or source.stem)[:500]
    original = _archive_audio(source, directory / RECORDING_FILES["source"])
    original.update(provenance)
    original["title"] = title
    recordings = {"source": original}
    if isolated is not None and Path(isolated).resolve() != source.resolve():
        stem = _archive_audio(Path(isolated), directory / RECORDING_FILES["isolated"])
        stem.update({"title": title, "derived_from": "source", "method": "Demucs piano separation"})
        recordings["isolated"] = stem
    metadata = {"recording_title": title, "requested_title": str(requested_title or "")[:500], "recordings": recordings}
    if (directory / "session.json").is_file():
        save_recording_metadata(directory, metadata)
    return metadata


def recording_path(session, directory, kind="source"):
    """Return validated audio, including an older transcription's existing source.

    Saved recording entries only address fixed filenames inside their session.
    Legacy source paths must decode as bounded audio, and are never resolved for
    compositions (whose source field contains a prompt rather than a file path).
    """
    if kind not in RECORDING_FILES or session.get("kind", "transcription") != "transcription":
        return None
    directory = Path(directory).resolve()
    data = session.get("recordings", {}).get(kind, {})
    candidate = directory / RECORDING_FILES[kind]
    if data and data.get("file") != RECORDING_FILES[kind]:
        return None
    if not candidate.is_file():
        if kind == "isolated":
            # Older batch jobs kept the separated stem beside numbered scores.
            # Only use that exact known layout, with its saved job confirming it.
            job_file = directory.parent / "job.json"
            if directory.name not in {"01", "02", "03", "04", "05"} or not job_file.is_file() or job_file.stat().st_size > 1_048_576:
                return None
            try:
                job = json.loads(job_file.read_text(encoding="utf-8"))
                if not job.get("piano_only") or len(job.get("items", [])) < int(directory.name):
                    return None
            except (ValueError, OSError, TypeError):
                return None
            candidate = directory.parent / f"isolated-{directory.name}" / "piano.wav"
            if candidate.resolve().parent != (directory.parent / f"isolated-{directory.name}"):
                return None
        elif not session.get("source"):
            return None
        else:
            candidate = Path(session["source"]).expanduser()
            if not candidate.is_absolute():
                candidate = directory / candidate
    elif candidate.resolve().parent != directory:
        return None
    try:
        _audio_info(candidate)
    except (OSError, ValueError, RuntimeError):
        return None
    return candidate.resolve()


def available_recordings(session, directory):
    """Public metadata for selector options; never includes absolute file paths."""
    result = {}
    for kind, filename in RECORDING_FILES.items():
        path = recording_path(session, directory, kind)
        if path is None:
            continue
        info = _audio_info(path)
        metadata = dict(session.get("recordings", {}).get(kind, {}))
        provenance = session.get("source_metadata") or {}
        metadata.update({"file": filename, "duration": info.frames / info.samplerate,
                         "sample_rate": info.samplerate, "channels": info.channels,
                         "title": metadata.get("title") or session.get("recording_title") or provenance.get("title") or path.stem})
        if kind == "source":
            for key in ("url", "page", "artist", "license", "license_url"):
                if not metadata.get(key) and provenance.get(key):
                    metadata[key] = provenance[key]
        result[kind] = metadata
    return result


def load_recording(session, directory, kind="source"):
    """Load real audio for desktop playback at its original pitch and rate."""
    import numpy as np
    import soundfile as sf

    path = recording_path(session, directory, kind)
    if path is None:
        raise ValueError("This recording is no longer available. Import the original audio again.")
    samples, rate = sf.read(path, dtype="float32", always_2d=True)
    if not np.isfinite(samples).all():
        raise ValueError("This recording contains invalid audio samples.")
    # Most output devices are stereo; retain native mono/stereo samples exactly.
    if samples.shape[1] > 2:
        samples = samples.mean(axis=1, keepdims=True)
    return samples, rate
