"""Cancellable batch rendering in a separate process."""
import argparse
import json
from pathlib import Path
import sys
from composer import arrangement
from piano_engine import build_outputs, read_midi, transcribe, report


def run(job):
    items = job['items']
    if not 1 <= len(items) <= 5:
        raise ValueError('A batch must contain one to five pieces.')
    base = Path(job['output'])
    failures = []
    completed = []
    for index, item in enumerate(items):
        import piano_engine
        def report(progress, message):
            overall = min(99, (index + max(0, min(100, progress)) / 100) * 100 / len(items))
            print(json.dumps({'message': message, 'progress': overall, 'item_index': index + 1, 'item_count': len(items)}), flush=True)
        piano_engine.report = report
        report(0, f"Creating {index + 1} of {len(items)} · {item.get('title', 'Piano piece')}")
        try:
            recording_metadata = {}
            target = base / f'{index + 1:02d}'
            provenance = {}
            if item.get('session'):
                from simplify_score import simplify
                simplify(item['session'], target)
                completed.append(str(target / 'session.json'))
                continue
            if item.get('neural'):
                from neural_music import generate_piece
                notes, bpm, title, provenance = generate_piece(job.get('prompt', ''), job['bars'], lambda progress, message: report(progress * .74, message), seed=None)
                sections, kind, source = [], 'neural-composition', job.get('prompt', '')
            elif 'plan' in item:
                plan = item['plan']
                notes, sections = arrangement(plan, job['bars'])
                bpm, title = plan['bpm'], plan['title']
                kind, source = job['kind'], job.get('prompt', '')
            else:
                if item.get('youtube'):
                    from video_audio import import_video
                    path, fetched_title = import_video(item['youtube'], base / f'input-{index + 1:02d}', report)
                    # The chosen video is the recording we actually heard. Keep
                    # a requested catalog label separate from its real identity.
                    source_title = fetched_title
                else:
                    path = Path(item['path'])
                    source_title = item.get('title') or path.stem
                bpm, title = job['bpm'], source_title
                original = path
                if job.get('piano_only') and path.suffix.lower() not in ('.mid', '.midi'):
                    from piano_separation import isolate_piano
                    path = isolate_piano(path, base / f'isolated-{index + 1:02d}/piano.wav', report)
                grid, threshold = job.get('grid', .5), job.get('threshold', .5)
                notes = read_midi(path, bpm, grid) if path.suffix.lower() in ('.mid', '.midi') else transcribe(path, bpm, grid, threshold)
                sections, kind, source = [], 'transcription', str(original)
                from source_audio import archive_recordings
                report(76, 'Keeping the original recording for accurate listening…')
                recording_metadata = archive_recordings(target, original, isolated=path if path != original else None,
                                                        requested_title=item.get('title', ''), source_title=source_title)
            plan = item.get('plan', {})
            if not provenance:
                provenance = {key: plan[key] for key in ('composer_version', 'style', 'seed', 'arrangement_seed', 'accompaniment') if key in plan}
            from playable import basic_arrangement
            if kind == 'transcription':
                # Keep the detected melody/bass pitches and the selected timing
                # grid, but discard dense middle voices.  A player never has to
                # press more than one note with either hand at the same time.
                notes = basic_arrangement(notes, grid=grid)
                provenance['arrangement'] = f'Basic transcription: melody + bass, {grid:g}-beat rhythm'
            else:
                notes = basic_arrangement(notes, job.get('bars', 32) * 4)
                provenance['arrangement'] = 'Basic: one note per hand, quarter-note rhythm'
            build_outputs(notes, bpm, title, target, source, kind, sections, composition=provenance)
            if recording_metadata:
                from source_audio import save_recording_metadata
                save_recording_metadata(target, recording_metadata)
            completed.append(str(target / 'session.json'))
        except Exception as exc:
            import traceback
            traceback.print_exc(file=sys.stderr)
            failures.append({'title': item.get('title', 'Piece'), 'error': str(exc)})
            report(100, f"Could not create {item.get('title', 'piece')}: {exc}")
    print(json.dumps({'batch_done': {'completed': completed, 'failures': failures}}), flush=True)
    if not completed:
        raise ValueError('; '.join(f["error"] for f in failures))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('job', type=Path)
    args = parser.parse_args()
    try:
        run(json.loads(args.job.read_text()))
    except Exception as exc:
        print(json.dumps({'error': str(exc)}), flush=True)
        sys.exit(1)
