"""Pianivo's loopback-only website: the desktop engine, shared local library.

Run with the supplied Python environment. Never bind this private-library server
publicly; hosted use needs authentication, isolated storage and resource quotas.
"""
from __future__ import annotations
import argparse
import atexit
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
from urllib.parse import quote, unquote, urlencode, urlsplit
import uuid
import zipfile

from flask import Flask, jsonify, request, send_file, send_from_directory
from werkzeug.exceptions import HTTPException
from creative_ai import CreativeAI, character_prompt
from generation_time import ProgressClock

MODULE = Path(__file__).resolve().parent
ALLOWED_AUDIO = {'.wav', '.mp3', '.flac', '.ogg', '.aif', '.aiff', '.mid', '.midi'}


def create_app(base=None, *, hosted=False):
    base = Path(base or MODULE).resolve()
    static_base = MODULE if hosted else base
    sessions = base / 'sessions'
    uploads = base / '.web-uploads'
    images = base / 'images'
    for folder in (sessions, uploads, images): folder.mkdir(parents=True, exist_ok=True)
    app = Flask(__name__, static_folder=None)
    app.config.update(MAX_CONTENT_LENGTH=150 * 1024 * 1024, JSON_SORT_KEYS=False)
    ai = CreativeAI()
    jobs = {}
    lock = threading.RLock()
    local_ai_lock = threading.Lock()
    app.extensions['cadence'] = {'jobs': jobs, 'ai': ai, 'base': base}

    def contained(folder, name):
        if not name or '\x00' in name: raise ValueError('Choose a valid saved file.')
        target = (folder / name).resolve()
        if not target.is_relative_to(folder) or target == folder: raise ValueError('That file is outside your library.')
        return target

    def session_path(identifier):
        directory = contained(sessions, identifier)
        path = contained(sessions, (directory / 'session.json').relative_to(sessions).as_posix())
        if not path.is_file(): raise FileNotFoundError('That score was not found.')
        return path

    def media_url(identifier, name):
        return '/media?' + urlencode({'session': identifier, 'file': name})

    def read_session(identifier, full=True):
        path = session_path(identifier)
        data = json.loads(path.read_text())
        if not full:
            return {'id': identifier, **{k: data.get(k) for k in ('title', 'bpm', 'duration', 'kind')},
                    'pages': len(data['pages']), 'composition': data.get('composition', {})}
        # Local filenames and provenance remain on this computer, but no absolute paths
        # are needed in the browser client.
        from source_audio import available_recordings
        data['recordings'] = available_recordings(data, path.parent)
        for kind, recording in data['recordings'].items():
            recording['audio_url'] = media_url(identifier, kind + '.wav')
        data.pop('source', None)
        data.update(id=identifier, page_urls=[media_url(identifier, name) for name in data['pages']],
                    audio_url=media_url(identifier, 'piano.wav'),
                    exports={kind: media_url(identifier, name) for kind, name in
                             [('pdf', 'score.pdf'), ('mid', 'piano.mid'), ('musicxml', 'score.musicxml'),
                              ('wav', 'piano.wav'), ('png', 'pages.zip')]})
        return data

    def history():
        try:
            values = json.loads((base / 'search-history.json').read_text())
            return [v for v in values if isinstance(v, str)][:12]
        except (OSError, ValueError): return []

    def save_history(query):
        with lock:
            values = [query] + [v for v in history() if v.casefold() != query.casefold()]
            temporary = base / 'search-history.web.tmp'
            temporary.write_text(json.dumps(values[:12]))
            temporary.replace(base / 'search-history.json')

    def body():
        data = request.get_json(silent=True)
        if not isinstance(data, dict): raise ValueError('Send a JSON object.')
        return data

    def number(value, lo, hi, name, integer=False):
        try: result = float(value)
        except (TypeError, ValueError): raise ValueError(f'Choose a valid {name}.')
        if not lo <= result <= hi or (integer and result != int(result)):
            raise ValueError(f'{name.capitalize()} must be between {lo} and {hi}.')
        return int(result) if integer else result

    def text(value, limit=4000):
        if not isinstance(value, str) or len(value) > limit: raise ValueError('The text is too long or invalid.')
        return value.strip()

    @app.before_request
    def local_only():
        hostname = urlsplit('http://' + request.host).hostname
        if not hosted and hostname not in ('localhost', '127.0.0.1', '::1'):
            return jsonify(error='This private Pianivo server accepts local browser connections only.'), 403
        origin = request.headers.get('Origin')
        if request.headers.get('Sec-Fetch-Site') == 'cross-site' or (origin and origin != request.host_url.rstrip('/')):
            return jsonify(error='Open Pianivo directly in your local browser.'), 403
        if request.method == 'POST' and request.path != '/api/upload' and not request.is_json:
            return jsonify(error='JSON requests are required.'), 415

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Content-Security-Policy'] = "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        if request.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.errorhandler(Exception)
    def error(exc):
        if isinstance(exc, HTTPException): return jsonify(error=exc.description), exc.code
        status = 404 if isinstance(exc, FileNotFoundError) else 400 if isinstance(exc, (ValueError, KeyError)) else 500
        if status == 500: app.logger.exception('Pianivo request failed')
        return jsonify(error=str(exc)[:700] if status != 500 else 'This action failed. Check the server log and try again.'), status

    @app.get('/')
    def index(): return send_from_directory(static_base / 'web', 'index.html')

    @app.get('/<name>')
    def web_asset(name):
        if name not in ('styles.css', 'app.js', 'favicon.svg', 'manifest.json'): raise FileNotFoundError()
        return send_from_directory(static_base / 'web', name)

    @app.get('/assets/<path:name>')
    def asset(name):
        if name != 'cadence-hero.png': raise FileNotFoundError()
        return send_from_directory(static_base / 'assets', name)

    @app.get('/api/config')
    def config():
        from piano_sound import VOICES
        return jsonify(voices=VOICES, tunings=[432, 440, 442], ai_configured=ai.configured, models=ai.status(),
                       history=history(), version='Pianivo Web 2.0', local=not hosted, hosted=hosted,
                       active_job=next(({'id': j['id'], 'kind': j.get('kind', 'generation')} for j in jobs.values() if j['status'] == 'running'), None))

    @app.get('/api/library')
    def library():
        result = []
        paths = sorted(sessions.rglob('session.json'), key=lambda p: p.stat().st_mtime, reverse=True)
        for path in paths:
            try: result.append(read_session(path.parent.relative_to(sessions).as_posix(), False))
            except (ValueError, KeyError, OSError): continue
        return jsonify(sessions=result)

    @app.post('/api/history/clear')
    def clear_search_history():
        body()
        with lock:
            temporary = base / 'search-history.web.tmp'
            temporary.write_text('[]', encoding='utf-8')
            temporary.replace(base / 'search-history.json')
        return jsonify(history=[])

    @app.get('/api/session')
    def session(): return jsonify(read_session(request.args.get('id', '')))

    @app.get('/media')
    def media():
        identifier = request.args.get('session', '')
        path = session_path(identifier)
        name = request.args.get('file', '')
        data = json.loads(path.read_text())
        if name in ('source.wav', 'isolated.wav'):
            from source_audio import recording_path
            target = recording_path(data, path.parent, name.split('.')[0])
            if target is None: raise FileNotFoundError('The original recording is no longer available.')
            return send_file(target, conditional=True)
        allowed = set(data['pages']) | {'score.pdf', 'piano.mid', 'score.musicxml', 'piano.wav'}
        if name == 'pages.zip':
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
                for page in data['pages']:
                    target = contained(path.parent, page)
                    archive.write(target, Path(page).name)
            buffer.seek(0)
            return send_file(buffer, mimetype='application/zip', as_attachment=True, download_name='Pianivo-score-pages.zip')
        if name.startswith('voice-') and name.endswith('.wav') and '/' not in name: allowed.add(name)
        if name not in allowed: raise FileNotFoundError('This export does not exist.')
        target = contained(path.parent, name)
        if not target.is_file(): raise FileNotFoundError('This export has not been rendered yet.')
        return send_file(target, conditional=True, as_attachment=name in {'piano.mid', 'score.musicxml'}, download_name=name)

    @app.get('/api/search')
    def search():
        from artist_catalog import search_catalog
        query = text(request.args.get('q', ''), 250)
        mode = request.args.get('mode', 'Songs')
        if mode not in ('Songs', 'Artists'): raise ValueError('Choose songs or artists.')
        results, corrected = search_catalog(query, mode)
        save_history(query)
        return jsonify(query=corrected, results=results)

    @app.get('/api/videos')
    def videos():
        from video_audio import find_videos
        query = text(request.args.get('q', ''), 300)
        if not query: raise ValueError('Enter a song or artist first.')
        return jsonify(videos=find_videos(query))

    @app.post('/api/upload')
    def upload():
        if request.mimetype != 'application/octet-stream': raise ValueError('Upload an audio or MIDI file.')
        filename = Path(unquote(request.headers.get('X-Filename', 'recording'))).name
        suffix = Path(filename).suffix.lower()
        if suffix not in ALLOWED_AUDIO: raise ValueError('Choose WAV, MP3, FLAC, OGG, AIFF, or MIDI.')
        token = uuid.uuid4().hex + suffix
        target = uploads / token
        try:
            count = 0
            with target.open('xb') as stream:
                while chunk := request.stream.read(1024 * 1024):
                    count += len(chunk)
                    if count > app.config['MAX_CONTENT_LENGTH']: raise ValueError('The upload exceeds 150 MB.')
                    stream.write(chunk)
            if not count: raise ValueError('That file is empty.')
        except BaseException:
            target.unlink(missing_ok=True)
            raise
        return jsonify(upload_id=token, title=Path(filename).stem)

    def update(job, **values):
        with lock:
            if 'progress' in values:
                values['progress'] = max(job.get('progress', 0), values['progress'])
                job['clock'].observe(values['progress'])
            job.update(values)
            if values.get('status') in ('complete', 'failed', 'cancelled'): job['clock'].finish()

    def stopped(job): return job['cancel'].is_set()

    def execute(job, function):
        try:
            function(job)
            if not stopped(job): update(job, status='complete', progress=100)
        except Exception as exc:
            if not stopped(job): update(job, status='failed', error=str(exc)[:1000], message=str(exc)[:500])
            app.logger.warning('Pianivo background job failed: %s', exc)
        finally:
            update(job, process=None)

    def new_job(function, kind='generation'):
        with lock:
            if any(j['status'] == 'running' for j in jobs.values()):
                raise ValueError('A music job is already running. Wait or cancel it before starting another.')
            identifier = uuid.uuid4().hex
            job = {'id': identifier, 'kind': kind, 'status': 'running', 'progress': 0, 'message': 'Getting ready…',
                   'completed': [], 'failures': [], 'cancel': threading.Event(), 'process': None, 'clock': ProgressClock()}
            jobs[identifier] = job
            # Keep polling state bounded without deleting files from the library.
            for old in list(jobs)[:-30]:
                if jobs[old]['status'] != 'running': jobs.pop(old)
        threading.Thread(target=execute, args=(job, function), daemon=True).start()
        return jsonify(job_id=identifier)

    def run_process(job, command, cwd):
        if stopped(job): return
        env = dict(os.environ, PYTHONUNBUFFERED='1', NUMBA_CACHE_DIR=str(base / '.cache/numba'),
                   MPLCONFIGDIR=str(base / '.cache/matplotlib'), TORCH_HOME=str(base / '.cache/torch'))
        log = cwd / 'web-engine.log'
        with log.open('w') as errors:
            with lock:
                if stopped(job): return
                process = subprocess.Popen(command, cwd=MODULE, env=env, stdout=subprocess.PIPE,
                                           stderr=errors, text=True, start_new_session=True)
                job['process'] = process
            for line in process.stdout:
                try: event = json.loads(line)
                except ValueError: continue
                if stopped(job): continue
                if 'message' in event: update(job, message=event['message'], progress=event.get('progress', 0))
                if 'result' in event:
                    result = Path(event['result']).resolve().parent
                    if result.is_relative_to(sessions):
                        identifier = result.relative_to(sessions).as_posix()
                        with lock:
                            if identifier not in job['completed']: job['completed'].append(identifier)
                if 'batch_done' in event: update(job, failures=event['batch_done'].get('failures', []))
                if 'error' in event: update(job, error=event['error'])
            code = process.wait()
        if code and not stopped(job): raise ValueError(job.get('error') or 'The music engine could not finish. Check web-engine.log in the new session.')

    @app.post('/api/generate')
    def generate():
        data = body()
        kind = data.get('kind', 'local')
        if kind not in ('local', 'neural', 'transcription'): raise ValueError('Choose a valid generation mode.')
        bars = number(data.get('bars', 48), 32, 64, 'length', True)
        if bars not in (32, 48, 64): raise ValueError('Choose 32, 48, or 64 bars.')
        count = number(data.get('count', 1), 1, 5, 'piece count', True)
        bpm = number(data.get('bpm', 100), 40, 240, 'tempo')
        grid = number(data.get('grid', .5), .25, 1, 'rhythm detail')
        if grid not in (.25, .5, 1): raise ValueError('Choose a supported rhythm detail.')
        threshold = number(data.get('threshold', .5), .2, .8, 'note sensitivity')
        prompt = text(data.get('prompt', ''))
        items = []
        if kind == 'transcription':
            from video_audio import youtube_url
            source_items = data.get('items', [])
            if not isinstance(source_items, list) or not 1 <= len(source_items) <= 5: raise ValueError('Choose one to five recordings.')
            for item in source_items:
                if not isinstance(item, dict): raise ValueError('Choose a valid recording.')
                title = text(item.get('title', ''), 250)
                if item.get('youtube'): items.append({'youtube': youtube_url(text(item['youtube'], 2000)), 'title': title})
                else:
                    path = contained(uploads, text(item.get('upload_id', ''), 100))
                    if not path.is_file() or path.suffix not in ALLOWED_AUDIO: raise FileNotFoundError('Please attach your recording again.')
                    items.append({'path': str(path), 'title': title})
        elif not prompt: raise ValueError('Describe the music you want to make.')
        if kind == 'neural' and not ai.configured:
            raise ValueError('Install the local music model with Install Local AI.command first.')
        def work(job):
            from composer import local_plans, validate_plan
            output = sessions / ('web-' + job['id'])
            output.mkdir()
            resolved = items
            if kind == 'local':
                update(job, message='Writing your musical ideas…')
                plans = local_plans(prompt, count)
                if len(plans) != count: raise ValueError('The AI returned a different number of pieces. Please try again.')
                resolved = [{'plan': validate_plan(plan), 'title': plan['title']} for plan in plans]
            if kind == 'neural':
                resolved = [{'neural': True, 'title': f'Original piano {i+1}'} for i in range(count)]
            if stopped(job): return
            spec = {'items': resolved, 'output': str(output), 'bars': bars, 'kind': kind,
                    'prompt': prompt, 'bpm': bpm, 'grid': grid, 'threshold': threshold,
                    'piano_only': bool(data.get('piano_only', False))}
            job_file = output / 'job.json'
            job_file.write_text(json.dumps(spec))
            run_process(job, [sys.executable, str(MODULE / 'studio_jobs.py'), str(job_file)], output)
            update(job, message='Your complete score is ready.' if not job['failures'] else 'Finished with some recordings unavailable.')
        return new_job(work)

    @app.get('/api/job')
    def job_status():
        with lock:
            job = jobs.get(request.args.get('id', ''))
            if not job: raise FileNotFoundError('That job is no longer available. Check your library.')
            public = {k: v for k, v in job.items() if k not in ('process', 'cancel', 'clock')}
            if 'clock' in job: public.update(job['clock'].snapshot())
            return jsonify(public)

    def cancel_job(job):
        with lock:
            if job['status'] != 'running': return
            job['cancel'].set()
            if 'clock' in job: job['clock'].finish()
            job.update(status='cancelled', message='Generation cancelled. Completed scores are in your library.')
            process = job.get('process')
            if process and process.poll() is None:
                try: os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError: pass

    @app.post('/api/cancel')
    def cancel():
        job = jobs.get(body().get('job_id'))
        if not job: raise FileNotFoundError('That job is no longer running.')
        cancel_job(job)
        return jsonify(status=job['status'])

    @app.post('/api/simplify')
    def simplify_saved_score():
        path = session_path(text(body().get('id', ''), 300))
        def work(job):
            output = sessions / ('basic-' + job['id']) / '01'
            output.mkdir(parents=True)
            update(job, message='Keeping the melody and bass, simplifying chords…')
            run_process(job, [sys.executable, str(MODULE / 'simplify_score.py'), str(path), str(output)], output)
            update(job, message='Your basic version is ready. The original is preserved.')
        return new_job(work)

    @app.post('/api/render')
    def render():
        from piano_sound import VOICES
        data = body()
        identifier = text(data.get('id', ''), 300)
        path = session_path(identifier)
        voice = data.get('voice', VOICES[0])
        if voice not in VOICES: raise ValueError('Choose a piano sound from the menu.')
        speed = number(data.get('speed', 1), .25, 2, 'practice speed')
        tuning = number(data.get('tuning', 440), 432, 446, 'tuning')
        digest = hashlib.sha256(json.dumps([voice, speed, tuning]).encode()).hexdigest()[:16]
        target = path.parent / ('voice-' + digest + '.wav')
        def work(job):
            if not target.exists():
                update(job, message='Preparing your selected piano sound…')
                spec = path.parent / ('render-' + job['id'] + '.json')
                spec.write_text(json.dumps({'session': str(path), 'output': str(target), 'voice': voice, 'speed': speed, 'tuning': tuning}))
                run_process(job, [sys.executable, str(MODULE / 'web_worker.py'), str(spec)], path.parent)
            if not stopped(job): update(job, audio_url=media_url(identifier, target.name), speed=speed, message='Piano sound ready.')
        return new_job(work, 'render')

    @app.post('/api/recommend-speed')
    def practice_speed():
        from practice_speed import recommend_speed
        data = body()
        score = json.loads(session_path(text(data.get('id', ''), 300)).read_text())
        return jsonify(recommend_speed(score, data.get('level', 'Beginner')))

    @app.get('/api/tutorial')
    def tutorial():
        from tutorial import TOUR_STEPS
        return jsonify(steps=TOUR_STEPS, seconds=sum(step['seconds'] for step in TOUR_STEPS))

    @app.post('/api/chat')
    def chat():
        data = body()
        values = data.get('history', [])
        if not isinstance(values, list) or not 1 <= len(values) <= 32: raise ValueError('Send a short conversation.')
        sanitized = []
        for value in values:
            if not isinstance(value, dict) or value.get('role') not in ('user', 'assistant'): raise ValueError('Invalid chat message.')
            sanitized.append({'role': value['role'], 'content': text(value.get('content', ''))})
        if not local_ai_lock.acquire(False): raise ValueError('An AI request is already running. Please wait.')
        try: return jsonify(reply=ai.chat(sanitized))
        finally: local_ai_lock.release()

    @app.post('/api/image')
    def make_image():
        fields = body().get('fields', {})
        if not isinstance(fields, dict) or len(fields) > 12: raise ValueError('Describe your character using the form.')
        fields = {text(k, 40): text(v, 700) for k, v in fields.items()}
        prompt = character_prompt(fields)
        if not local_ai_lock.acquire(False): raise ValueError('An AI request is already running. Please wait.')
        try:
            image_bytes = ai.image(prompt)
            name = 'character-' + uuid.uuid4().hex + '.png'
            (images / name).write_bytes(image_bytes)
            return jsonify(image_url='/image/' + name)
        finally: local_ai_lock.release()

    @app.get('/image/<name>')
    def character_image(name):
        if not name.startswith('character-') or not name.endswith('.png'): raise FileNotFoundError()
        return send_file(contained(images, name))

    def shutdown():
        for job in list(jobs.values()): cancel_job(job)
    app.extensions['cadence']['shutdown'] = shutdown
    if not hosted: atexit.register(shutdown)
    return app


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Pianivo local website')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--open', action='store_true')
    args = parser.parse_args()
    url = f'http://127.0.0.1:{args.port}'
    if args.open:
        import webbrowser
        def open_browser():
            try: webbrowser.get('chrome').open(url)
            except webbrowser.Error: webbrowser.open(url)
        threading.Timer(1.2, open_browser).start()
    print(f'Pianivo is ready at {url} — keep this window open.', flush=True)
    create_app().run(host='127.0.0.1', port=args.port, threaded=True, debug=False, use_reloader=False)
