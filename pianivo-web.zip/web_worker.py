"""Isolated, cancellable piano rendering for the browser player."""
import json
import sys
from pathlib import Path
import soundfile as sf
from piano_engine import Note
from piano_sound import render

if __name__ == '__main__':
    spec = json.loads(Path(sys.argv[1]).read_text())
    data = json.loads(Path(spec['session']).read_text())
    audio, rate = render([Note(**n) for n in data['notes']], data['bpm'], spec['speed'], spec['voice'], spec['tuning'])
    target = Path(spec['output'])
    temporary = target.with_suffix('.partial.wav')
    sf.write(temporary, audio, rate, subtype='PCM_16')
    temporary.replace(target)
